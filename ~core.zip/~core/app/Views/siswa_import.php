<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<style>
    .custom-file-button input[type=file] {
        margin-left: -2px !important;
    }

    .custom-file-button input[type=file]::-webkit-file-upload-button {
        display: none;
    }

    .custom-file-button input[type=file]::file-selector-button {
        display: none;
    }

    .custom-file-button:hover label {
        background-color: #dde0e3;
        cursor: pointer;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>
        <form action="<?= base_url('master/siswa_import_proses') ?>" method="POST" enctype="multipart/form-data">
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">File Import</label>
                <div class="col-sm-10">
                    <div class="input-group custom-file-button">
                        <label class="input-group-text" for="inputGroupFile">Pilih file</label>
                        <input type="file" name="file" class="form-control" id="inputGroupFile" required>
                    </div>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">&nbsp;</label>
                <div class="col-sm-10">
                    <a href="<?= base_url('master/siswa') ?>" class="btn btn-outline-warning">Kembali</a>
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </div>
            </div>
        </form>
        <div class="alert alert-primary d-flex align-items-center" role="alert">
            <i data-feather="alert-circle" class="mg-r-10"></i>
            Sebelum melakukan Import data Siswa, silahkan menggunakan Format File Import yang bisa di <a href="<?= base_url('import_siswa.xlsx') ?>" class="btn btn-warning btn-sm mx-3">DOWNLOAD Disini</a>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>