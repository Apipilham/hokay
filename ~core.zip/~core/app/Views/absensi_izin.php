<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link href="<?= base_url() ?>/assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-sm table-bordered" id="" width="100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>NISN</th>
                        <th>NAMA</th>
                        <th>TGL</th>
                        <th>SURAT DOKTER</th>
                        <th>AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($izin)) : ?>
                        <?php $no = 1; ?>
                        <?php foreach ($izin as $row) : ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td><?= $row['nisn'] ?></td>
                                <td><?= $row['nama'] ?></td>
                                <td><?= $row['tanggal_mulai'] ?> - <?= $row['tanggal_selesai'] ?></td>
                                <td><a href="<?= $setting->online_url ?>/uploads/izin/<?= $row['surat_dokter'] ?>" class="badge bg-success text-white" target="_blank">Cek Surat Dokter</a></td>
                                <td><a href="<?= base_url('absensi/manual/?nisn=' . $row['nisn']) ?>" class="badge bg-primary text-white">Absensi Manual</a></td>
                            </tr>
                            <?php $no++ ?>
                        <?php endforeach ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="6">Tidak ada data.</td>
                        </tr>
                    <?php endif ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>

<?= $this->endSection() ?>