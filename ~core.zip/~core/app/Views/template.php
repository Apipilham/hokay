<!doctype html>
<html lang="en" class="light-theme">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?= base_url() ?>/assets/images/favicon-32x32.png" type="image/png" />
    <!--plugins-->
    <link href="<?= base_url() ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <!-- Bootstrap CSS -->
    <link href="<?= base_url() ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/bootstrap-extended.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/style.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- loader-->
    <link href="<?= base_url() ?>/assets/css/pace.min.css" rel="stylesheet" />


    <!--Theme Styles-->
    <link href="<?= base_url() ?>/assets/css/dark-theme.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/light-theme.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/semi-dark.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/header-colors.css" rel="stylesheet" />

    <?= $this->renderSection('css') ?>

    <title><?= $title ?></title>
</head>

<body>


    <!--start wrapper-->
    <div class="wrapper">
        <!--start top header-->
        <header class="top-header">
            <nav class="navbar navbar-expand">
                <div class="mobile-toggle-icon d-xl-none">
                    <i class="bi bi-list"></i>
                </div>
                <div class="top-navbar d-none d-xl-block">
                    <ul class="navbar-nav align-items-center">
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url() ?>">Dashboard Finger</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('dashboard/qrcode') ?>">Scan QRCode</a>
                        </li>
                    </ul>
                </div>
                <div class="top-navbar-right ms-3 ms-auto">
                    <ul class="navbar-nav align-items-center">
                        <li class="nav-item dropdown dropdown-large">
                            <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" data-bs-toggle="dropdown">
                                <div class="user-setting d-flex align-items-center gap-1">
                                    <img src="<?= base_url() ?>/assets/images/avatars/avatar-1.png" class="user-img" alt="">
                                    <div class="user-name d-none d-sm-block"><?= $admin->nama ?></div>
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="<?= base_url('admin') ?>">
                                        <div class="d-flex align-items-center">
                                            <img src="<?= base_url() ?>/assets/images/avatars/avatar-1.png" alt="" class="rounded-circle" width="60" height="60">
                                            <div class="ms-3">
                                                <h6 class="mb-0 dropdown-user-name"><?= $admin->nama ?></h6>
                                                <small class="mb-0 dropdown-user-designation text-secondary">Administrator</small>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?= base_url('admin') ?>">
                                        <div class="d-flex align-items-center">
                                            <div class="setting-icon"><i class="bi bi-person"></i></div>
                                            <div class="setting-text ms-3"><span>Edit Profile</span></div>
                                        </div>
                                    </a>
                                    <a class="dropdown-item" href="<?= base_url('admin/password') ?>">
                                        <div class="d-flex align-items-center">
                                            <div class="setting-icon"><i class="bi bi-lock-fill"></i></div>
                                            <div class="setting-text ms-3"><span>Ubah Password</span></div>
                                        </div>
                                    </a>
                                    <a class="dropdown-item" href="<?= base_url('home/logout') ?>">
                                        <div class="d-flex align-items-center">
                                            <div class="setting-icon"><i class="bi bi-box-arrow-right"></i></div>
                                            <div class="setting-text ms-3"><span>Logout</span></div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!--end top header-->

        <!--start sidebar -->
        <aside class="sidebar-wrapper">
            <div class="iconmenu">
                <div class="nav-toggle-box">
                    <div class="nav-toggle-icon"><i class="bi bi-list"></i></div>
                </div>
                <ul class="nav nav-pills flex-column">
                    <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="right" title="Dashboard">
                        <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-dashboard" type="button"><i class="bi bi-speedometer2"></i></button>
                    </li>
                    <?php if ($session['level'] == 'level_admin') : ?>
                        <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="right" title="User Manajer">
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-user" type="button"><i class="bi bi-person"></i></button>
                        </li>
                    <?php endif ?>
                    <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="right" title="Absensi">
                        <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-absensi" type="button"><i class="bi bi-grid-fill"></i></button>
                    </li>
                    <?php if ($session['level'] == 'level_admin' || $session['level'] == 'level_operator') : ?>
                        <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="right" title="Master Data Siswa">
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-master-data" type="button"><i class="bi bi-people"></i></button>
                        </li>
                    <?php endif ?>
                    <?php if ($session['level'] == 'level_admin') : ?>
                        <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="right" title="Setting Mesin Finger">
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-setting-mesin" type="button"><i class="bi bi-fingerprint"></i></button>
                        </li>
                        <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="right" title="Setting Whatsapp API">
                            <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-whatsapp-api" type="button"><i class="bi bi-whatsapp"></i></button>
                        </li>
                    <?php endif ?>
                    <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="right" title="Dashboard Absensi">
                        <button class="nav-link" data-bs-toggle="pill" data-bs-target="#pills-home" type="button"><i class="bi bi-house-heart-fill"></i></button>
                    </li>
                </ul>
            </div>
            <div class="textmenu">
                <div class="brand-logo">
                    <img src="<?= base_url() ?>/assets/images/brand-logo-2.png" width="140" alt="" />
                </div>
                <div class="tab-content">
                    <div class="tab-pane fade" id="pills-dashboard">
                        <div class="list-group list-group-flush">
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-0">Dashboard</h5>
                                </div>
                                <small class="mb-0">Statistik Aplikasi</small>
                            </div>
                            <a href="<?= base_url('admin/dashboard') ?>" class="list-group-item"><i class="bi bi-check"></i>Statistik</a>
                        </div>
                    </div>
                    <?php if ($session['level'] == 'level_admin') : ?>
                        <div class="tab-pane fade" id="pills-user">
                            <div class="list-group list-group-flush">
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-0">User Manajer</h5>
                                    </div>
                                    <small class="mb-0">Kelola User Login</small>
                                </div>
                                <a href="<?= base_url('user') ?>" class="list-group-item"><i class="bi bi-check"></i>Data User</a>
                                <a href="<?= base_url('user/add') ?>" class="list-group-item"><i class="bi bi-lock"></i>Tambah User</a>
                            </div>
                        </div>
                    <?php endif ?>
                    <div class="tab-pane fade" id="pills-absensi">
                        <div class="list-group list-group-flush">
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-0">Absensi</h5>
                                </div>
                                <small class="mb-0">Kelola absensi lokal</small>
                            </div>
                            <a href="<?= base_url('absensi/riwayat') ?>" class="list-group-item"><i class="bi bi-clock-history"></i>Riwayat Absensi</a>
                            <!-- <a href="<?= base_url('absensi/izin') ?>" class="list-group-item"><i class="bi bi-envelope-exclamation"></i>Siswa Izin</a> -->
                            <a href="<?= base_url('absensi/cek') ?>" class="list-group-item"><i class="bi bi-check"></i>Cek Belum Absensi</a>
                            <a href="<?= base_url('absensi/manual') ?>" class="list-group-item"><i class="bi bi-plus"></i>Absensi Manual</a>

                            <a href="<?= base_url('absensi/laporan') ?>" class="list-group-item"><i class="bi bi-file-earmark-spreadsheet"></i>Laporan Absensi</a>
                        </div>
                    </div>
                    <?php if ($session['level'] == 'level_admin' || $session['level'] == 'level_operator') : ?>
                        <div class="tab-pane fade" id="pills-master-data">
                            <div class="list-group list-group-flush">
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-0">Master Data</h5>
                                    </div>
                                    <small class="mb-0">Setting master data absensi</small>
                                </div>
                                <a href="<?= base_url('master/walikelas') ?>" class="list-group-item"><i class="bi bi-person-bounding-box"></i>Data Wali Kelas</a>
                                <a href="<?= base_url('master/kelas') ?>" class="list-group-item"><i class="bi bi-file-ruled-fill"></i>Data Kelas</a>
                                <a href="<?= base_url('master/siswa') ?>" class="list-group-item"><i class="bi bi-people"></i>Data Siswa</a>
                                <!-- <a href="<?= base_url('master/siswa_add') ?>" class="list-group-item"><i class="bi bi-person-plus"></i>Tambah Siswa Baru</a>
                            <a href="<?= base_url('master/siswa_import') ?>" class="list-group-item"><i class="bi bi-download"></i>Import Data Siswa</a>
                            <a href="<?= base_url('master/siswa_export') ?>" class="list-group-item"><i class="bi bi-upload"></i>Export Data Siswa</a>
                            <a href="<?= base_url('master/siswa_qrcode') ?>" class="list-group-item"><i class="bi bi-upload"></i>Cetak QRCode Siswa</a> -->
                            </div>
                        </div>
                    <?php endif ?>
                    <?php if ($session['level'] == 'level_admin') : ?>
                        <div class="tab-pane fade" id="pills-setting-mesin">
                            <div class="list-group list-group-flush">
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-0">Mesin Finger</h5>
                                    </div>
                                    <small class="mb-0">Setting koneksi fingerprint</small>
                                </div>
                                <a href="<?= base_url('master/finger') ?>" class="list-group-item"><i class="bi bi-sliders"></i>Setting Mesin Finger</a>
                                <a href="<?= base_url('master/finger_import') ?>" class="list-group-item"><i class="bi bi-download"></i>Import Data</a>
                                <a href="<?= base_url('master/finger_data') ?>" class="list-group-item"><i class="bi bi-list"></i>Data Kehadiran</a>
                                <a href="<?= base_url('master/finger_clear') ?>" class="list-group-item"><i class="bi bi-trash"></i>Hapus Data Kehadiran</a>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-whatsapp-api">
                            <div class="list-group list-group-flush">
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-0">Whatsapp API</h5>
                                    </div>
                                    <small class="mb-0">Setting Whatsapp API</small>
                                </div>
                                <a href="<?= base_url('master/wa') ?>" class="list-group-item"><i class="bi bi-whatsapp"></i>Setting WA API</a>
                                <a href="<?= base_url('master/wa_tes') ?>" class="list-group-item"><i class="bi bi-whatsapp"></i>Tes Kirim</a>
                                <a href="<?= base_url('master/wa_masal') ?>" class="list-group-item"><i class="bi bi-whatsapp"></i>Kirim WA Masal</a>
                            </div>
                        </div>
                    <?php endif ?>
                    <div class="tab-pane fade" id="pills-home">
                        <div class="list-group list-group-flush">
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h5 class="mb-0">Homepage</h5>
                                </div>
                                <small class="mb-0">Menuju halaman Absensi,</small>
                            </div>
                            <a href="<?= base_url('dashboard') ?>" class="list-group-item"><i class="bi bi-fingerprint"></i></i>Absensi Fingerprint</a>
                            <a href="<?= base_url('dashboard/qrcode') ?>" class="list-group-item"><i class="bi bi-qr-code-scan"></i>Absensi QRCode</a>
                        </div>
                    </div>
                </div>
            </div>
        </aside>
        <!--start sidebar -->

        <!--start content-->
        <main class="page-content">
            <!--breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <div class="breadcrumb-title pe-3"><?= $title ?></div>
                <div class="ps-3">
                    <?= $subtitle ?>
                </div>
            </div>
            <!--end breadcrumb-->

            <?= $this->renderSection('content') ?>


        </main>
        <!--end page main-->


        <!--start overlay-->
        <div class="overlay nav-toggle-icon"></div>
        <!--end overlay-->

        <!--Start Back To Top Button-->
        <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
        <!--End Back To Top Button-->

        <!--start switcher-->
        <div class="switcher-body">
            <button class="btn btn-primary btn-switcher shadow-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling"><i class="bi bi-paint-bucket me-0"></i></button>
            <div class="offcanvas offcanvas-end shadow border-start-0 p-2" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling">
                <div class="offcanvas-header border-bottom">
                    <h5 class="offcanvas-title" id="offcanvasScrollingLabel">Theme Customizer</h5>
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"></button>
                </div>
                <div class="offcanvas-body">
                    <h6 class="mb-0">Theme Variation</h6>
                    <hr>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="LightTheme" value="option1" checked>
                        <label class="form-check-label" for="LightTheme">Light</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="DarkTheme" value="option2">
                        <label class="form-check-label" for="DarkTheme">Dark</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="SemiDarkTheme" value="option3">
                        <label class="form-check-label" for="SemiDarkTheme">Semi Dark</label>
                    </div>
                    <hr>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions" id="MinimalTheme" value="option3">
                        <label class="form-check-label" for="MinimalTheme">Minimal Theme</label>
                    </div>
                    <hr />
                    <h6 class="mb-0">Header Colors</h6>
                    <hr />
                    <div class="header-colors-indigators">
                        <div class="row row-cols-auto g-3">
                            <div class="col">
                                <div class="indigator headercolor1" id="headercolor1"></div>
                            </div>
                            <div class="col">
                                <div class="indigator headercolor2" id="headercolor2"></div>
                            </div>
                            <div class="col">
                                <div class="indigator headercolor3" id="headercolor3"></div>
                            </div>
                            <div class="col">
                                <div class="indigator headercolor4" id="headercolor4"></div>
                            </div>
                            <div class="col">
                                <div class="indigator headercolor5" id="headercolor5"></div>
                            </div>
                            <div class="col">
                                <div class="indigator headercolor6" id="headercolor6"></div>
                            </div>
                            <div class="col">
                                <div class="indigator headercolor7" id="headercolor7"></div>
                            </div>
                            <div class="col">
                                <div class="indigator headercolor8" id="headercolor8"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end switcher-->

    </div>
    <!--end wrapper-->


    <!-- Bootstrap bundle JS -->
    <script src="<?= base_url() ?>/assets/js/bootstrap.bundle.min.js"></script>
    <!--plugins-->
    <script src="<?= base_url() ?>/assets/js/jquery.min.js"></script>
    <script src="<?= base_url() ?>/assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="<?= base_url() ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <script src="<?= base_url() ?>/assets/js/pace.min.js"></script>
    <!--app-->
    <script src="<?= base_url() ?>/assets/js/app.js"></script>

    <?= $this->renderSection('js') ?>


</body>

</html>