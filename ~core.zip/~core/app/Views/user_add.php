<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php if (session()->getFlashdata('message')) : ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php endif ?>
        <form action="<?= base_url('user/save') ?>" method="POST">
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-9">
                    <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Password</label>
                <div class="col-sm-9">
                    <input type="text" name="password" class="form-control" placeholder="Password" required>
                </div>
            </div>
            <hr>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Nama Lengkap</label>
                <div class="col-sm-9">
                    <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Nomor Whatsapp</label>
                <div class="col-sm-9">
                    <input type="number" name="hp" class="form-control" placeholder="Nomor Whatsapp">
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Level Login</label>
                <div class="col-sm-9">
                    <select name="level" class="form-select" required>
                        <option value="">Pilih Level</option>
                        <option value="1">Administrator</option>
                        <option value="2">Operator</option>
                    </select>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">&nbsp;</label>
                <div class="col-sm-9">
                    <a href="<?= base_url('user') ?>" class="btn btn-outline-warning">Kembali</a>
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </div>
            </div>
        </form>
    </div>
</div>


<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>