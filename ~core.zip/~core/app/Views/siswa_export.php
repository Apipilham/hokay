<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<style>
    .custom-file-button input[type=file] {
        margin-left: -2px !important;
    }

    .custom-file-button input[type=file]::-webkit-file-upload-button {
        display: none;
    }

    .custom-file-button input[type=file]::file-selector-button {
        display: none;
    }

    .custom-file-button:hover label {
        background-color: #dde0e3;
        cursor: pointer;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>
        <div class="alert alert-primary d-flex align-items-center" role="alert">
            <i data-feather="alert-circle" class="mg-r-10"></i>
            Download Data ini untuk melakukan Import Data Siswa ke mesin Finger.
        </div>
        <a href="<?= base_url('master/siswa') ?>" class="btn btn-outline-warning">Kembali</a>
        <a href="<?= base_url('master/siswa_export_proses') ?>" class="btn btn-primary"><i class="bi bi-arrow-down-circle"></i> Download Data Siswa</a>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>