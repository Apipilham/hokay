<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.css">
<style>
    .fc-day-grid-event .fc-content {
        white-space: normal !important;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <div id='calendar'></div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            eventTimeFormat: { // like '14:30:00'
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            },
            events: [
                <?php foreach ($absensi as $ab) : ?>
                    <?php
                    if ($ab->status == 'masuk') {
                        $color = 'green';
                    } else if ($ab->status == 'pulang') {
                        $color = 'blue';
                    } else if ($ab->status == 'terlambat') {
                        $color = 'orange';
                    } else if ($ab->status == 'alpha') {
                        $color = 'red';
                    } else if ($ab->status == 'izin') {
                        $color = 'gray';
                    } else if ($ab->status == 'sakit') {
                        $color = 'purple';
                    } else {
                        $color = 'black';
                    }
                    ?> {
                        title: '<?= $ab->status ?>\n@<?= $ab->jam ?>',
                        start: '<?= $ab->tanggal ?>',
                        end: '<?= $ab->tanggal ?>',
                        color: '<?= $color ?>'
                    },
                <?php endforeach ?>
            ],
            eventContent: function(arg) {
                return {
                    html: arg.event.title.replace(/\n/g, '<br>')
                }
            },
        });
        calendar.render();
    });
</script>
<?= $this->endSection() ?>