<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link href="<?= base_url() ?>/assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-danger">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>

        <form class="form-inline" action="" method="GET">
            <div class="row">
                <div class="col">
                    Mulai
                    <input type="date" name="start" class="form-control">
                </div>
                <div class="col">
                    Sampai
                    <input type="date" name="end" class="form-control">
                </div>
                <div class="col">
                    Kelas
                    <select name="kelas" class="form-select">
                        <option value="all">Semua Kelas</option>
                        <?php foreach ($kelas as $k) : ?>
                            <option value="<?= $k->kelas ?>"><?= $k->kelas ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
                <div class="col">
                    <br>
                    <input type="submit" class="btn btn-primary" value="Filter">
                </div>
            </div>
        </form>
        <hr>

        <?php if (!empty($out)) : ?>
            <?php
            $db = db_connect();
            $s = $_GET['start'];
            $e = $_GET['end'];
            $awal = date('d', strtotime($s));
            $akhir = date('d', strtotime($e));

            $now = strtotime($e); // or your date as well
            $your_date = strtotime($s);
            $datediff = $now - $your_date;

            $count = round($datediff / (60 * 60 * 24)) + 1;
            ?>
            <h4>Rekap <?= $_GET['start'] ?> - <?= $_GET['end'] ?></h4>
            <div class="table-responsive" id="printableArea">
                <table class="table table-striped table-sm table-bordered" id="tbl_exporttable_to_xls" width="100%">
                    <thead>
                        <tr>
                            <th rowspan="2" class="text-center">#</th>
                            <th rowspan="2" class="text-center">NISN</th>
                            <th rowspan="2" class="text-center">NAMA</th>
                            <th rowspan="2" class="text-center">KELAS</th>
                            <th colspan="<?= $count ?>" class="text-center">TANGGAL</th>
                        </tr>
                        <tr>
                            <?php
                            for ($i = $awal; $i <= $akhir; $i++) {
                                echo '<th class="text-center">' . (int)$i . '</th>';
                            }

                            ?>
                        </tr>
                    </thead>
                    <?= $out; ?>
                </table>
            </div>
            <a href="#" class="btn btn-primary" onclick="printDiv('printableArea')">Cetak</a>
            <button class="btn btn-success" onclick="ExportToExcel('xlsx')">Export table to excel</button>

            <!-- <a href="<?= base_url('absensi/laporan_cetak/' . $_GET['start'] . '/' . $_GET['end']) ?>" class="btn btn-primary" target="_blank"><i class="bi bi-printer-fill"></i> Cetak</a> -->
        <?php endif ?>
    </div>
</div>


<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>

<script>
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;
    }

    function ExportToExcel(type, fn, dl) {
        var elt = document.getElementById('tbl_exporttable_to_xls');
        var wb = XLSX.utils.table_to_book(elt, {
            sheet: "sheet1"
        });
        return dl ?
            XLSX.write(wb, {
                bookType: type,
                bookSST: true,
                type: 'base64'
            }) :
            XLSX.writeFile(wb, fn || ('Laporan Absensi.' + (type || 'xlsx')));
    }
</script>
<?= $this->endSection() ?>