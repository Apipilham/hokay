<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>
        <form action="<?= base_url('master/finger_save') ?>" method="POST">
            <!-- <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">URL Absensi Online</label>
                <div class="col-sm-9">
                    <input type="text" name="online_url" class="form-control" placeholder="" value="<?= $setting->online_url ?>" required>
                </div>
            </div> -->
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 1</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger1" class="form-control" placeholder="" value="<?= $setting->ip_finger1 ?>" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 2</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger2" class="form-control" placeholder="" value="<?= $setting->ip_finger2 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 3</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger3" class="form-control" placeholder="" value="<?= $setting->ip_finger3 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 4</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger4" class="form-control" placeholder="" value="<?= $setting->ip_finger4 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 5</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger5" class="form-control" placeholder="" value="<?= $setting->ip_finger5 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 6</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger6" class="form-control" placeholder="" value="<?= $setting->ip_finger6 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 7</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger7" class="form-control" placeholder="" value="<?= $setting->ip_finger7 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 8</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger8" class="form-control" placeholder="" value="<?= $setting->ip_finger8 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 9</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger9" class="form-control" placeholder="" value="<?= $setting->ip_finger9 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">IP Mesin Finger 10</label>
                <div class="col-sm-9">
                    <input type="text" name="ip_finger10" class="form-control" placeholder="" value="<?= $setting->ip_finger10 ?>">
                    <small class="text-muted">Kosongi jika tidak digunakan.</small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Rentang Jam Masuk</label>
                <div class="col-sm-9">
                    <input type="text" name="jam_masuk" class="form-control" placeholder="" value="<?= $setting->jam_masuk ?>" required>
                    <small id="passwordHelpBlock" class="form-text text-muted">
                        Gunakan format seperti 06:00-08:00
                    </small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Rentang Jam Pulang</label>
                <div class="col-sm-9">
                    <input type="text" name="jam_pulang" class="form-control" placeholder="" value="<?= $setting->jam_pulang ?>" required>
                    <small id="passwordHelpBlock" class="form-text text-muted">
                        Gunakan format seperti 10:00-14:00
                    </small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">&nbsp;</label>
                <div class="col-sm-9">
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </div>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>