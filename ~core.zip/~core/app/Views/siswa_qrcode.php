<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<style>
    .padding {
        border: 1px solid #8338ec;
        margin: 5px;
        float: left;
        border-radius: 15px;
    }

    .font {
        height: 375px;
        width: 250px;
        position: relative;
        border-radius: 10px;
    }

    .top {
        height: 30%;
        width: 100%;
        background-color: #8338ec;
        position: relative;
        z-index: 5;
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
    }

    .bottom {
        height: 70%;
        width: 100%;
        background-color: white;
        position: absolute;
        border-bottom-left-radius: 15px;
        border-bottom-right-radius: 15px;
    }

    .top img {
        height: 100px;
        width: 100px;
        background-color: #e6ebe0;
        border-radius: 10px;
        position: absolute;
        top: 60px;
        left: 75px;
    }

    .bottom p {
        position: relative;
        top: 50px;
        text-align: center;
        text-transform: capitalize;
        font-weight: bold;
        font-size: 20px;
        text-emphasis: spacing;
        margin: 0;
    }

    .bottom .desi {
        font-size: 12px;
        color: grey;
        font-weight: normal;
        margin: 0;
    }

    .bottom .no {
        font-size: 15px;
        font-weight: normal;
        margin: 0;
    }

    .barcode img {
        height: 120px;
        width: 120px;
        text-align: center;
    }

    .barcode {
        text-align: center;
        position: relative;
        top: 50px;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>
        <div id="qrcode">
            <?php foreach ($qrcode as $qr) : ?>
                <div class="padding">
                    <div class="font">
                        <div class="top">
                            <img src="<?= base_url('assets/images/' . $qr['foto']) ?>">
                        </div>
                        <div class="bottom">
                            <p><?= $qr['nama'] ?></p>
                            <p class="desi"><?= $qr['nisn'] ?></p>
                            <div class="barcode">
                                <?= $qr['qr'] ?>
                            </div>
                            <p class="no"><?= $qr['nomor'] ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
            <div style="clear:both"></div>
        </div>
        <hr>
        <a href="<?= base_url('master/siswa') ?>" class="btn btn-outline-warning">Kembali</a>
        <a href="#" class="btn btn-primary" onclick="printDiv('qrcode')">Cetak</a>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;
    }
</script>
<?= $this->endSection() ?>