<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak</title>
</head>

<body onload="window.print()">
    <h1>Laporan Absensi</h1>
    Tanggal: <?= $segment[2] ?> s/d <?= $segment[3] ?>
    <hr>
    <table width="100%" border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th>#</th>
                <th>TANGGAL</th>
                <th>JAM</th>
                <th>NISN</th>
                <th>NAMA</th>
                <th>KELAS</th>
                <th>STATUS</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach ($filter as $row) : ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $row->tanggal ?></td>
                    <td><?= $row->jam ?></td>
                    <td><?= $row->nisn ?></td>
                    <td><?= $row->nama ?></td>
                    <td><?= $row->kelas ?></td>
                    <td><?= $row->status ?></td>
                </tr>
                <?php $no++ ?>
            <?php endforeach ?>
        </tbody>
    </table>
</body>

</html>