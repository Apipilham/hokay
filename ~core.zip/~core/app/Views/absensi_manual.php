<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>
        <form action="<?= base_url('absensi/save') ?>" method="POST">
            <div class="form-group row mb-2">
                <label class="col-sm-3 col-form-label">Tanggal</label>
                <div class="col-sm-9">
                    <input type="date" name="tanggal" class="form-control" placeholder="Tanggal" value="<?= (isset($_GET['nisn'])) ? date("Y-m-d") : '' ?>" required>
                </div>
            </div>
            <div class="form-group row mb-2">
                <label class="col-sm-3 col-form-label">Jam</label>
                <div class="col-sm-9">
                    <input type="time" name="jam" class="form-control" placeholder="Jam" value="<?= (isset($_GET['nisn'])) ? date("H:i") : '' ?>" required>
                </div>
            </div>
            <div class="form-group row mb-2">
                <label class="col-sm-3 col-form-label">NISN</label>
                <div class="col-sm-9">
                    <input type="number" name="nisn" class="form-control" placeholder="NISN" value="<?= (isset($_GET['nisn'])) ? $_GET['nisn'] : '' ?>" required>
                </div>
            </div>
            <div class="row mb-3 mb-2">
                <label class="col-sm-3 col-form-label">Status Absensi</label>
                <div class="col-sm-9">
                    <select name="status" id="" class="form-select">
                        <option value="masuk">Masuk</option>
                        <option value="terlambat">Terlambat</option>
                        <option value="pulang">Pulang</option>
                        <option value="izin">Izin</option>
                        <option value="sakit">Sakit</option>
                        <option value="alpha">Tidak Masuk</option>
                    </select>
                </div>
            </div>
            <!-- <div class="row mb-3 mb-2">
                <label class="col-sm-3 col-form-label">Kirim Pesan WA ke Wali</label>
                <div class="col-sm-9">
                    <select name="pesan" id="" class="form-select">
                        <option value="0">Tidak</option>
                        <option value="1">Ya, Kirim Pesan Whatsapp</option>
                    </select>
                </div>
            </div> -->
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">&nbsp;</label>
                <div class="col-sm-9">
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </div>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>