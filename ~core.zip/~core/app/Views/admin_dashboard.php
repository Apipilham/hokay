<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="row">
    <div class="col-12 col-lg-12 col-xl-6 d-flex">
        <div class="card radius-10 w-100">
            <div class="card-body">
                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-xl-3 row-cols-xxl-3 g-3">
                    <div class="col">
                        <div class="card radius-10 mb-0 border shadow-none">
                            <div class="card-body text-center">
                                <div class="widget-icon mx-auto mb-3 bg-tiffany text-white">
                                    <i class="bi bi-person"></i>
                                </div>
                                <h3 class="mb-0"><?= $total_admin ?></h3>
                                <p class="mb-0">Administrator</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card radius-10 mb-0 border shadow-none">
                            <div class="card-body text-center">
                                <div class="widget-icon mx-auto mb-3 bg-danger text-white">
                                    <i class="bi bi-person-bounding-box"></i>
                                </div>
                                <h3 class="mb-0"><?= $total_walikelas ?></h3>
                                <p class="mb-0">Wali Kelas</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card radius-10 mb-0 border shadow-none">
                            <div class="card-body text-center">
                                <div class="widget-icon mx-auto mb-3 bg-success text-white">
                                    <i class="bi bi-people-fill"></i>
                                </div>
                                <h3 class="mb-0"><?= $total_siswa ?></h3>
                                <p class="mb-0">Siswa</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card radius-10 mb-0 border shadow-none">
                            <div class="card-body text-center">
                                <div class="widget-icon mx-auto mb-3 bg-pink text-white">
                                    <i class="bi bi-clipboard-check"></i>
                                </div>
                                <h3 class="mb-0"><?= $total_siswa_hadir ?></h3>
                                <p class="mb-0">Siswa Hadir</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card radius-10 mb-0 border shadow-none">
                            <div class="card-body text-center">
                                <div class="widget-icon mx-auto mb-3 bg-purple text-white">
                                    <i class="bi bi-hourglass-split"></i>
                                </div>
                                <h3 class="mb-0"><?= $total_siswa_terlambat ?></h3>
                                <p class="mb-0">Siswa Terlambat</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card radius-10 mb-0 border shadow-none">
                            <div class="card-body text-center">
                                <div class="widget-icon mx-auto mb-3 bg-orange text-white">
                                    <i class="bi bi-patch-exclamation-fill"></i>
                                </div>
                                <h3 class="mb-0"> <?= $total_siswa_belum_absen[0]->total ?></h3>
                                <p class="mb-0">Belum Absensi</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-12 col-xl-6 d-flex">
        <div class="card radius-10 w-100">
            <div class="card-header bg-transparent">
                <div class="row g-3 align-items-center">
                    <div class="col">
                        <h5 class="mb-0">Siswa Hadir Tepat Waktu</h5>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div id="chart1"></div>
            </div>
        </div>
    </div>
</div><!--end row-->

<?php
$db = db_connect();
$total_siswa = $db->query("SELECT count(nisn) as total_siswa FROM siswa")->getResult();

$today = date("Y-m-d");
$date_1 = date('Y-m-d', strtotime('-1 days', strtotime(date("Y-m-d"))));
$date_2 = date('Y-m-d', strtotime('-2 days', strtotime(date("Y-m-d"))));
$date_3 = date('Y-m-d', strtotime('-3 days', strtotime(date("Y-m-d"))));
$date_4 = date('Y-m-d', strtotime('-4 days', strtotime(date("Y-m-d"))));
$date_5 = date('Y-m-d', strtotime('-5 days', strtotime(date("Y-m-d"))));
$date_6 = date('Y-m-d', strtotime('-6 days', strtotime(date("Y-m-d"))));
$date_7 = date('Y-m-d', strtotime('-7 days', strtotime(date("Y-m-d"))));
$date_8 = date('Y-m-d', strtotime('-8 days', strtotime(date("Y-m-d"))));
$date_9 = date('Y-m-d', strtotime('-9 days', strtotime(date("Y-m-d"))));
$date_10 = date('Y-m-d', strtotime('-10 days', strtotime(date("Y-m-d"))));

$total_today = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$today' AND status='masuk'")->getResult();
$total_1 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_1' AND status='masuk'")->getResult();
$total_2 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_2' AND status='masuk'")->getResult();
$total_3 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_3' AND status='masuk'")->getResult();
$total_4 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_4' AND status='masuk'")->getResult();
$total_5 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_5' AND status='masuk'")->getResult();
$total_6 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_6' AND status='masuk'")->getResult();
$total_7 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_7' AND status='masuk'")->getResult();
$total_8 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_8' AND status='masuk'")->getResult();
$total_9 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_9' AND status='masuk'")->getResult();
$total_10 = $db->query("SELECT count(nisn) as total FROM absensi WHERE tanggal='$date_10' AND status='masuk'")->getResult();
?>


<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script src="<?= base_url() ?>/assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>

<script>
    // chart 1
    var options = {
        series: [{
            name: "Total Hadir",
            data: [<?= $total_10[0]->total ?>, <?= $total_9[0]->total ?>, <?= $total_8[0]->total ?>, <?= $total_7[0]->total ?>, <?= $total_6[0]->total ?>, <?= $total_5[0]->total ?>, <?= $total_4[0]->total ?>, <?= $total_3[0]->total ?>, <?= $total_2[0]->total ?>, <?= $total_1[0]->total ?>, <?= $total_today[0]->total ?>]
        }],
        chart: {
            foreColor: '#9a9797',
            type: "bar",
            //width: 130,
            height: 450,
            toolbar: {
                show: !1
            },
            zoom: {
                enabled: !1
            },
            dropShadow: {
                enabled: 0,
                top: 3,
                left: 14,
                blur: 4,
                opacity: .12,
                color: "#3461ff"
            },
            sparkline: {
                enabled: !1
            }
        },
        markers: {
            size: 0,
            colors: ["#3461ff", "#12bf24"],
            strokeColors: "#fff",
            strokeWidth: 2,
            hover: {
                size: 7
            }
        },
        plotOptions: {
            bar: {
                horizontal: !1,
                columnWidth: "40%",
                endingShape: "rounded"
            }
        },
        legend: {
            show: false,
            position: 'top',
            horizontalAlign: 'left',
            offsetX: -20
        },
        dataLabels: {
            enabled: !1
        },
        grid: {
            show: false,
            // borderColor: '#eee',
            // strokeDashArray: 4,
        },
        stroke: {
            show: !0,
            // width: 3,
            curve: "smooth"
        },
        colors: ["#12bf24"],
        xaxis: {
            categories: ["<?= $date_10 ?>", "<?= $date_9 ?>", "<?= $date_8 ?>", "<?= $date_7 ?>", "<?= $date_6 ?>", "<?= $date_5 ?>", "<?= $date_4 ?>", "<?= $date_3 ?>", "<?= $date_2 ?>", "<?= $date_1 ?>", "<?= $today ?>"]
        },
        yaxis: {
            min: 0,
            max: <?= $total_siswa[0]->total_siswa ?>,
            scaleIntegersOnly: true,
            labels: {
                formatter: function(val) {
                    return val.toFixed(0);
                }
            },

            tickAmount: 4,
        },
        tooltip: {
            theme: 'dark',
            y: {
                formatter: function(val) {
                    return "" + val + ""
                }
            }
        }
    };

    var chart = new ApexCharts(document.querySelector("#chart1"), options);
    chart.render();
</script>
<?= $this->endSection() ?>