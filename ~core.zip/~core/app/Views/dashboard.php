<!doctype html>
<html lang="en" class="light-theme">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?= base_url() ?>/assets/images/favicon-32x32.png" type="image/png" />
    <!-- Bootstrap CSS -->
    <link href="<?= base_url() ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/bootstrap-extended.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/style.css" rel="stylesheet" />
    <link href="<?= base_url() ?>/assets/css/icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <!-- loader-->
    <link href="<?= base_url() ?>/assets/css/pace.min.css" rel="stylesheet" />

    <title>Dashboard Absensi</title>
</head>

<body class="bg-surface">

    <!--start wrapper-->
    <div class="wrapper">

        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-white rounded-0 border-bottom">
                <div class="container">
                    <a class="navbar-brand" href="#"><img src="<?= base_url() ?>/assets/images/brand-logo-2.png" width="140" alt="" /></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mb-2 mb-lg-0 align-items-center">
                            <li class="nav-item">
                                <a class="nav-link" href="<?= base_url() ?>">Dashboard Finger</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?= base_url('dashboard/qrcode') ?>">Scan QRCode</a>
                            </li>
                        </ul>

                        <div class="d-flex ms-auto ms-3 gap-3">
                            <?php if (isset($session['logged_in'])) : ?>
                                <a href="<?= base_url('admin/dashboard') ?>" class="btn btn-primary btn-sm px-4 radius-30">KELOLA ABSENSI</a>
                                <a href="<?= base_url('home/logout') ?>" class="btn btn-danger btn-sm px-4 radius-30">Logout</a>
                            <?php else : ?>
                                <a href="<?= base_url('login') ?>" class="btn btn-primary btn-sm px-4 radius-30">Login</a>
                            <?php endif ?>
                        </div>
                    </div>
                </div>
            </nav>
        </header>

        <!--start content-->
        <main class="authentication-content">
            <div class="container">
                <div class="mt-4">
                    <div class="card rounded-0 overflow-hidden shadow-none border mb-5 mb-lg-0 p-3">
                        <h4 class="mg-b-0 tx-spacing--1">Absensi Realtime</h4>

                        <div id="data"></div>
                    </div>
                </div>
            </div>
        </main>

        <!--end page main-->

        <footer class="bg-white border-top p-3 text-center fixed-bottom">
            <p class="mb-0">Copyright &copy; 2022. All right reserved.</p>
        </footer>

    </div>
    <!--end wrapper-->


    <!-- Bootstrap bundle JS -->
    <script src="<?= base_url() ?>/assets/js/bootstrap.bundle.min.js"></script>

    <!--plugins-->
    <script src="<?= base_url() ?>/assets/js/jquery.min.js"></script>
    <script src="<?= base_url() ?>/assets/js/pace.min.js"></script>

    <script>
        var autoload = setInterval(
            function() {
                $('#data').load('<?= base_url() ?>/api/api.php').fadeIn('slow');
            }, 10000
        );
    </script>
</body>

</html>