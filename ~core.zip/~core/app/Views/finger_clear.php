<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>

        <form action="<?= base_url('master/finger_clear_proses') ?>" method="POST" enctype="multipart/form-data">
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">Pilih Mesin Finger</label>
                <div class="col-sm-10">
                    <select name="finger" id="" class="form-select">
                        <option value="0">Pilih Mesin</option>
                        <option value="<?= $setting->ip_finger1 ?>">Mesin Finger 1</option>
                        <option value="<?= $setting->ip_finger2 ?>">Mesin Finger 2</option>
                        <option value="<?= $setting->ip_finger3 ?>">Mesin Finger 3</option>
                        <option value="<?= $setting->ip_finger4 ?>">Mesin Finger 4</option>
                        <option value="<?= $setting->ip_finger5 ?>">Mesin Finger 5</option>
                        <option value="<?= $setting->ip_finger6 ?>">Mesin Finger 6</option>
                        <option value="<?= $setting->ip_finger7 ?>">Mesin Finger 7</option>
                        <option value="<?= $setting->ip_finger8 ?>">Mesin Finger 8</option>
                        <option value="<?= $setting->ip_finger9 ?>">Mesin Finger 9</option>
                        <option value="<?= $setting->ip_finger10 ?>">Mesin Finger 10</option>
                    </select>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">&nbsp;</label>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Clear Data">
                </div>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>