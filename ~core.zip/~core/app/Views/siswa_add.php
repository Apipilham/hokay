<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <form action="<?= base_url('master/siswa_save') ?>" method="POST">
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">NISN</label>
                <div class="col-sm-9">
                    <input type="number" name="nisn" class="form-control" placeholder="NISN" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Nama Lengkap</label>
                <div class="col-sm-9">
                    <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Kelas</label>
                <div class="col-sm-9">
                    <select name="kelas" class="form-select" required>
                        <option value="">Pilih Kelas</option>
                        <?php foreach ($kelas as $kls) : ?>
                            <option value="<?= $kls->kelas ?>"><?= $kls->kelas ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Nama Wali</label>
                <div class="col-sm-9">
                    <input type="text" name="nama_wali" class="form-control" placeholder="Nama Wali" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Nomor Whatsapp Wali</label>
                <div class="col-sm-9">
                    <input type="number" name="nomor_wali" class="form-control" placeholder="Nomor Whatsapp Wali">
                    <small id="passwordHelpBlock" class="form-text text-muted">
                        Gunakan format nomor 62xxx. Contoh: 6285781814171
                    </small>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">&nbsp;</label>
                <div class="col-sm-9">
                    <a href="<?= base_url('master/siswa') ?>" class="btn btn-outline-warning">Kembali</a>
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </div>
            </div>
        </form>
    </div>
</div>


<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>