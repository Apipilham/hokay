<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link href="<?= base_url() ?>/assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <a href="<?= base_url('master/siswa_add') ?>" class="btn btn-primary"><i class="bi bi-person-plus"></i> Tambah Siswa Baru</a>
        <a href="<?= base_url('master/siswa_import') ?>" class="btn btn-info"><i class="bi bi-download"></i> Import Data Siswa</a>
        <a href="<?= base_url('master/siswa_export') ?>" class="btn btn-success"><i class="bi bi-upload"></i> Eksport Data Siswa</a>
        <a href="<?= base_url('master/siswa_qrcode') ?>" class="btn btn-warning"><i class="bi bi-printer"></i> Cetak QRCode Siswa</a>
        <hr>
        <?php if (session()->getFlashdata('message')) : ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php endif ?>

        <form method="post" action="<?php echo base_url('master/siswa_delete_batch') ?>" id="form-delete">
            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="table" width="100%">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="check-all"></th>
                            <th>#</th>
                            <th>NISN</th>
                            <th>NAMA LENGKAP</th>
                            <th>KELAS</th>
                            <th>NAMA WALI</th>
                            <th>NOMOR WALI</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>
            <button type="button" class="btn btn-danger" id="btn-delete">HAPUS YANG TERPILIH</button>
        </form>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#table').DataTable({
            processing: true,
            serverSide: true,
            ajax: '<?= base_url('master/siswa_data') ?>',
            order: [],
            columns: [{
                    data: 'checkbox',
                    orderable: false
                },
                {
                    data: 'no',
                    orderable: false
                },
                {
                    data: 'nisn'
                },
                {
                    data: 'nama'
                },
                {
                    data: 'kelas'
                },
                {
                    data: 'nama_wali'
                },
                {
                    data: 'nomor_wali'
                },
                {
                    data: 'aksi',
                    orderable: false
                },
            ]
        });
    });
</script>
<script>
    $(document).ready(function() { // Ketika halaman sudah siap (sudah selesai di load)
        $("#check-all").click(function() { // Ketika user men-cek checkbox all
            if ($(this).is(":checked")) // Jika checkbox all diceklis
                $(".check-item").prop("checked", true); // ceklis semua checkbox siswa dengan class "check-item"
            else // Jika checkbox all tidak diceklis
                $(".check-item").prop("checked", false); // un-ceklis semua checkbox siswa dengan class "check-item"
        });

        $("#btn-delete").click(function() { // Ketika user mengklik tombol delete
            var confirm = window.confirm("Apakah Anda yakin ingin menghapus data-data ini?"); // Buat sebuah alert konfirmasi

            if (confirm) // Jika user mengklik tombol "Ok"
                $("#form-delete").submit(); // Submit form
        });
    });
</script>
<?= $this->endSection() ?>