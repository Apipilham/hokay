<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>
        <form action="<?= base_url('admin/save') ?>" method="POST">
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">Nama Admin</label>
                <div class="col-sm-10">
                    <input type="text" name="nama" class="form-control" value="<?= $admin->nama ?>" required>
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="text" name="email" class="form-control" value="<?= $admin->email ?>" required>
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">No. HP/Whatsapp</label>
                <div class="col-sm-10">
                    <input type="text" name="hp" class="form-control" value="<?= $admin->hp ?>" required>
                    <small>Format: 6285781812171</small>
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">&nbsp;</label>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </div>
            </div>
        </form>
    </div>
</div>


<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>