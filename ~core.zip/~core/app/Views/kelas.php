<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link href="<?= base_url() ?>/assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?= $this->endSection() ?>

<?= $this->section('content') ?>


<div class="row">
    <div class="col-md-5">
        <div class="card shadow-sm radius-10 border-0 mb-3">
            <div class="card-body">
                <?php if (session()->getFlashdata('message')) : ?>
                    <div class="alert alert-info">
                        <?= session()->getFlashdata('message') ?>
                    </div>
                <?php endif ?>

                <h5>Tambah Kelas Baru:</h5>
                <hr>
                <form action="<?= base_url('master/kelas_save') ?>" method="post">
                    <div class="form-group mb-3">
                        <label for="">Nama Kelas</label>
                        <input type="text" name="kelas" class="form-control" placeholder="Nama Kelas" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Pilih Wali Kelas</label>
                        <select name="walikelas" class="form-select" required>
                            <option value="">Pilih Wali Kelas</option>
                            <?php foreach ($walikelas as $wk) : ?>
                                <option value="<?= $wk->id ?>"><?= $wk->nama ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label for="">ID Group Whatsapp</label>
                        <input type="text" name="id_group" class="form-control" placeholder="ID Group">
                    </div>
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card shadow-sm radius-10 border-0 mb-3">
            <div class="card-body">
                <h5>Daftar Kelas:</h5>
                <hr>
                <?php if (session()->getFlashdata('message2')) : ?>
                    <div class="alert alert-info">
                        <?= session()->getFlashdata('message2') ?>
                    </div>
                <?php endif ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="table" width="100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>KELAS</th>
                                <th>WALI KELAS</th>
                                <th>ID GROUP</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>




<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#table').DataTable({
            processing: true,
            serverSide: true,
            ajax: '<?= base_url('master/kelas_data') ?>',
            order: [],
            columns: [{
                    data: 'no',
                    orderable: false
                },
                {
                    data: 'kelas'
                },
                {
                    data: 'walikelas'
                },
                {
                    data: 'id_group'
                },
                {
                    data: 'aksi',
                    orderable: false
                },
            ]
        });
    });
</script>
<?= $this->endSection() ?>