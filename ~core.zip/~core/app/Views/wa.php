<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>
        <form action="<?= base_url('master/wa_save') ?>" method="POST">
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">URL request</label>
                <div class="col-sm-10">
                    <input type="url" name="whatsapp_api_url" class="form-control" placeholder="" value="<?= $setting->whatsapp_api_url ?>" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">WA API Key</label>
                <div class="col-sm-10">
                    <input type="text" name="whatsapp_api_key" class="form-control" placeholder="" value="<?= $setting->whatsapp_api_key ?>" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">Tujuan Notifikasi</label>
                <div class="col-sm-10">
                    <select name="tujuan" class="form-select">
                        <option value="1" <?= ($setting->tujuan == 1) ? 'selected' : '' ?>>Nomor Wali Murid</option>
                        <option value="2" <?= ($setting->tujuan == 2) ? 'selected' : '' ?>>Group Kelas</option>
                        <option value="3" <?= ($setting->tujuan == 3) ? 'selected' : '' ?>>Nomor Wali Murid & Group Kelas</option>
                    </select>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">Custom Pesan Teks</label>
                <div class="col-sm-5">
                    <textarea type="text" name="whatsapp_api_text" class="form-control" rows="10" placeholder="" required><?= $setting->whatsapp_api_text ?></textarea>
                </div>
                <div class="col-sm-5">
                    <p>Variabel yang bisa dimasukkan:</p>
                    <table class="table">
                        <tr>
                            <td>
                                <strong>[NISN]</strong>
                            </td>
                            <td> Untuk memasukkan NISN siswa</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[SISWA]</strong>
                            </td>
                            <td> Untuk memasukkan Nama siswa</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[KELAS]</strong>
                            </td>
                            <td> Untuk memasukkan Kelas siswa</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[WALI]</strong>
                            </td>
                            <td> Untuk memasukkan Nama wali murid</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[TANGGAL]</strong>
                            </td>
                            <td> Untuk memasukkan Tanggal Absensi</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[JAM]</strong>
                            </td>
                            <td> Untuk memasukkan Jam Absensi</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[STATUS]</strong>
                            </td>
                            <td> Untuk memasukkan Status Absensi</td>
                        </tr>
                    </table>

                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">&nbsp;</label>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </div>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>