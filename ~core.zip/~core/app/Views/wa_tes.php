<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body" style="height:400px">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>

        <form action="<?= base_url('master/wa_tes_send') ?>" method="POST">
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Nomor Whatsapp</label>
                <div class="col-sm-9">
                    <input type="number" name="phone" class="form-control" placeholder="6285781812171" required>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">Pesan</label>
                <div class="col-sm-9">
                    Otomatis dari setting
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-3 col-form-label">&nbsp;</label>
                <div class="col-sm-9">
                    <input type="submit" class="btn btn-primary" value="Kirim">
                </div>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>