<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body" style="height:500px">
        <?php
        // $url = $setting->whatsapp_api_url;
        // $parse = parse_url($url);
        // echo $parse['host']; // prints 'google.com'
        ?>
        <iframe src="http://localhost:8000" frameborder="0" width="100%" height="100%"></iframe>
        <!-- <div id="data"></div> -->

    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    // var autoload = setInterval(
    //     function() {
    //         $('#data').load('<?= base_url() ?>/master/wa_create').fadeIn('slow');
    //     }, 10000
    // );
</script>
<?= $this->endSection() ?>