<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<style>
    .custom-file-button input[type=file] {
        margin-left: -2px !important;
    }

    .custom-file-button input[type=file]::-webkit-file-upload-button {
        display: none;
    }

    .custom-file-button input[type=file]::file-selector-button {
        display: none;
    }

    .custom-file-button:hover label {
        background-color: #dde0e3;
        cursor: pointer;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?= session()->getFlashdata('message') ?>
            </div>
        <?php
        }
        ?>

        <form action="<?= base_url('master/finger_import_proses') ?>" method="POST" enctype="multipart/form-data">
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">Pilih Mesin Finger</label>
                <div class="col-sm-10">
                    <select name="finger" id="" class="form-select">
                        <option value="0">Pilih Mesin</option>
                        <option value="<?= $setting->ip_finger1 ?>">Mesin Finger 1</option>
                        <option value="<?= $setting->ip_finger2 ?>">Mesin Finger 2</option>
                        <option value="<?= $setting->ip_finger3 ?>">Mesin Finger 3</option>
                        <option value="<?= $setting->ip_finger4 ?>">Mesin Finger 4</option>
                        <option value="<?= $setting->ip_finger5 ?>">Mesin Finger 5</option>
                        <option value="<?= $setting->ip_finger6 ?>">Mesin Finger 6</option>
                        <option value="<?= $setting->ip_finger7 ?>">Mesin Finger 7</option>
                        <option value="<?= $setting->ip_finger8 ?>">Mesin Finger 8</option>
                        <option value="<?= $setting->ip_finger9 ?>">Mesin Finger 9</option>
                        <option value="<?= $setting->ip_finger10 ?>">Mesin Finger 10</option>
                    </select>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">File Import</label>
                <div class="col-sm-10">
                    <div class="input-group custom-file-button">
                        <label class="input-group-text" for="inputGroupFile">Pilih file</label>
                        <input type="file" name="file" class="form-control" id="inputGroupFile" required>
                    </div>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">&nbsp;</label>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Simpan">
                </div>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>