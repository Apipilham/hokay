<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <?php
        if (session()->getFlashdata('message')) {
        ?>
            <div class="alert alert-info">
                <?php foreach (session()->getFlashdata('message') as $msg) : ?>
                    Nomor: <?= $msg['nomor'] ?>, Status: <?= $msg['terkirim'] ?><br>
                <?php endforeach ?>
            </div>
        <?php
        }
        ?>

        <form action="<?= base_url('master/wa_masal_send') ?>" method="POST">

            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">Kelas</label>
                <div class="col-sm-10">
                    <select name="kelas" class="form-select">
                        <?php foreach ($kelas as $kls) : ?>
                            <option value="<?= $kls->kelas ?>"><?= $kls->kelas ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <div class="form-group row mb-3">
                <label class="col-sm-2 col-form-label">Pesan Teks</label>
                <div class="col-sm-6">
                    <textarea type="text" name="pesan" class="form-control" rows="10" placeholder="" required></textarea>
                </div>
                <div class="col-sm-4">
                    <p>Variabel yang bisa dimasukkan:</p>
                    <table class="table">
                        <tr>
                            <td>
                                <strong>[NISN]</strong>
                            </td>
                            <td> Untuk memasukkan NISN siswa</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[SISWA]</strong>
                            </td>
                            <td> Untuk memasukkan Nama siswa</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[KELAS]</strong>
                            </td>
                            <td> Untuk memasukkan Kelas siswa</td>
                        </tr>
                        <tr>
                            <td>
                                <strong>[WALI]</strong>
                            </td>
                            <td> Untuk memasukkan Nama wali murid</td>
                        </tr>
                    </table>

                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">&nbsp;</label>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Kirim">
                </div>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>