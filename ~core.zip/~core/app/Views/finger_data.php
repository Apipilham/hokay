<?= $this->extend('template') ?>

<?= $this->section('css') ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="card shadow-sm radius-10 border-0 mb-3">
    <div class="card-body">
        <form action="" method="GET">
            <select name="finger" id="" class="form-select" onchange="form.submit()">
                <option value="0">Pilih Mesin</option>
                <option value="<?= $setting->ip_finger1 ?>">Mesin Finger 1</option>
                <option value="<?= $setting->ip_finger2 ?>">Mesin Finger 2</option>
                <option value="<?= $setting->ip_finger3 ?>">Mesin Finger 3</option>
                <option value="<?= $setting->ip_finger4 ?>">Mesin Finger 4</option>
                <option value="<?= $setting->ip_finger5 ?>">Mesin Finger 5</option>
                <option value="<?= $setting->ip_finger6 ?>">Mesin Finger 6</option>
                <option value="<?= $setting->ip_finger7 ?>">Mesin Finger 7</option>
                <option value="<?= $setting->ip_finger8 ?>">Mesin Finger 8</option>
                <option value="<?= $setting->ip_finger9 ?>">Mesin Finger 9</option>
                <option value="<?= $setting->ip_finger10 ?>">Mesin Finger 10</option>
            </select>
        </form>
        <hr>
        <?php
        if (isset($_GET['finger'])) {
            $IP = $_GET['finger'];
        } else {
            $IP = '';
        }
        $Key = "0";
        ?>

        <!-- <form action="tarik-data.php">
            IP Address: <input type="Text" name="ip" value="<?= $IP ?>" size=15><BR>
            Comm Key: <input type="Text" name="key" size="5" value="<?= $Key ?>"><BR><BR>

            <input type="Submit" value="Download">
        </form>
        <BR> -->

        <?php
        if ($IP != "") { ?>
            <table class="table table-sm table-striped table-bordered">
                <tr align="center">
                    <td><B>UserID</B></td>
                    <td width="200"><B>Tanggal & Jam</B></td>
                    <td><B>Verifikasi</B></td>
                    <td><B>Status</B></td>
                </tr>
                <?php
                $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
                if ($Connect) {
                    $soap_request = "<GetAttLog><ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey><Arg><PIN xsi:type=\"xsd:integer\">All</PIN></Arg></GetAttLog>";
                    $newLine = "\r\n";
                    fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
                    fputs($Connect, "Content-Type: text/xml" . $newLine);
                    fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
                    fputs($Connect, $soap_request . $newLine);
                    $buffer = "";
                    while ($Response = fgets($Connect, 1024)) {
                        $buffer = $buffer . $Response;
                    }
                } else echo "Koneksi Gagal";



                $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
                $buffer = explode("\r\n", $buffer);
                // echo count($buffer);
                for ($a = 1; $a < count($buffer) - 1; $a++) {
                    $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
                    $PIN = Parse_Data($data, "<PIN>", "</PIN>");
                    $DateTime = Parse_Data($data, "<DateTime>", "</DateTime>");
                    $Verified = Parse_Data($data, "<Verified>", "</Verified>");
                    $Status = Parse_Data($data, "<Status>", "</Status>");
                ?>
                    <tr align="center">
                        <td><?php echo $PIN ?></td>
                        <td><?= $DateTime ?></td>
                        <td><?= $Verified ?></td>
                        <td><?= $Status ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } ?>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= $this->endSection() ?>