<?php

namespace App\Controllers;

use \Hermawan\DataTables\DataTable;
use \PhpOffice\PhpSpreadsheet\Spreadsheet;
use \PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use chillerlan\QRCode\{QRCode, QROptions};

class Master extends BaseController
{
    public function siswa()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Master Data Siswa',
            'subtitle' => 'Daftar semua siswa ada disini',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('siswa', $data);
    }

    public function siswa_data()
    {
        $db = db_connect();
        $data = $db->table('siswa')->select('id, nisn, nama, kelas, nama_wali, nomor_wali');

        return DataTable::of($data)
            ->add('checkbox', function ($row) {
                return '<input type="checkbox" class="check-item" name="id[]" value="' . $row->id . '">';
            })
            ->add('aksi', function ($row) {
                return '
                <a href="' . base_url('master/siswa_absensi/' . $row->nisn) . '" class="badge bg-success text-white">Data</a> 
                <a href="' . base_url('master/siswa_edit/' . $row->id) . '" class="badge bg-info text-white">Edit</a> 
                <a href="' . base_url('master/siswa_delete/' . $row->id) . '" class="badge bg-danger text-white">Delete</a>';
            })
            ->addNumbering('no')->toJson(true);
    }

    public function siswa_absensi($nisn)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Riwayat Absensi Siswa',
            'subtitle' => 'Riwayat Absensi Siswa',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'absensi'  => $db->table('absensi')->where(['nisn' => $nisn])->get()->getResult(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];

        return view('siswa_riwayat', $data);
    }

    public function siswa_add()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Tambah Siswa Baru',
            'subtitle' => 'Masukkan data siswa dengan benar dan lengkap',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'kelas'    => $db->table('kelas')->get()->getResult(),
        ];
        return view('siswa_add', $data);
    }

    public function siswa_edit($id)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Edit Siswa Baru',
            'subtitle' => 'Masukkan data siswa dengan benar dan lengkap',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'kelas'    => $db->table('kelas')->get()->getResult(),
            'siswa'    => $db->table('siswa')->where('id', $id)->get()->getRow(),
        ];

        return view('siswa_edit', $data);
    }

    public function siswa_save()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $rules = [
            'nisn' => [
                'rules' => 'is_unique[siswa.nisn,id,{id}]',
                'errors' => [
                    'is_unique' => 'NISN sudah terdaftar.',
                ]
            ],
        ];

        if ($this->validate($rules)) {

            $data = [
                'nisn'       => $this->request->getVar('nisn'),
                'nama'       => $this->request->getVar('nama'),
                'kelas'      => $this->request->getVar('kelas'),
                'nama_wali'  => $this->request->getVar('nama_wali'),
                'nomor_wali' => $this->request->getVar('nomor_wali'),
            ];

            if ($this->request->getVar('id') == null) {
                $db->table('siswa')->insert($data);
                session()->setFlashdata('message', 'Data berhasil di simpan.');
                return redirect()->to(base_url('master/siswa_add'));
            } else {
                $db->table('siswa')->where(['id' => $this->request->getVar('id')])->update($data);
                session()->setFlashdata('message', 'Data berhasil di simpan.');
                return redirect()->to(base_url('master/siswa_edit/' . $this->request->getVar('id')));
            }
        } else {
            session()->setFlashdata('message', 'GAGAL. NISN sudah terdaftar.');
            return redirect()->to(base_url('master/siswa_edit/' . $this->request->getVar('id')));
        }
    }

    public function siswa_import()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Import Data Siswa',
            'subtitle' => 'Import data siswa dengan format excel',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('siswa_import', $data);
    }

    public function siswa_import_proses()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $file_excel = $this->request->getFile('file');
        $ext = $file_excel->getClientExtension();
        if ($ext == 'xls') {
            $render = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
        } else {
            $render = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        }
        $spreadsheet = $render->load($file_excel);

        $data = $spreadsheet->getActiveSheet()->toArray();
        foreach ($data as $x => $row) {
            if ($x == 0) {
                continue;
            }

            $nisn = $row[1];
            $nama = $row[2];
            $kelas = $row[3];
            $nama_wali = $row[4];
            $nomor_wali = $row[5];

            $db = db_connect();

            $cekNis = $db->table('siswa')->getWhere(['nisn' => $nisn])->getResult();

            if (count($cekNis) > 0) {
                session()->setFlashdata('message', '<b style="color:red">Data Gagal di Import NIS ada yang sama</b>');
            } else {

                $simpandata = [
                    'nisn'       => $nisn,
                    'nama'       => $nama,
                    'kelas'      => $kelas,
                    'nama_wali'  => $nama_wali,
                    'nomor_wali' => $nomor_wali,
                ];

                $db->table('siswa')->insert($simpandata);
                session()->setFlashdata('message', 'Berhasil import excel');
            }
        }

        return redirect()->to('/master/siswa_import');
    }

    public function siswa_export()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Export Data Siswa',
            'subtitle' => 'Export data siswa untuk dimasukkan mesin finger',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('siswa_export', $data);
    }

    public function siswa_export_proses()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }
        $spreadsheet = new Spreadsheet();

        $spreadsheet->setActiveSheetIndex(0)
            ->setCellValue('A1', 'NISN')
            ->setCellValue('B1', 'NAMA');
        $column = 2;

        $db = db_connect();
        $siswa = $db->table('siswa')->get()->getResult();

        foreach ($siswa as $user) {
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue('A' . $column, $user->nisn)
                ->setCellValue('B' . $column, $user->nama);

            $column++;
        }

        $writer = new Xlsx($spreadsheet);
        $filename = date('Y-m-d-His') . '-Data-Siswa';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename=' . $filename . '.xlsx');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
    }

    public function siswa_qrcode()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'QRCode Data Siswa',
            'subtitle' => 'Cetak QRCode data siswa',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];

        $options = new QROptions([
            'version' => 2,
        ]);

        $siswa = $db->table('siswa')->get()->getResult();
        $qr = array();
        foreach ($siswa as $s) {
            $qr[] = array('qr' => '<img src="' . (new QRCode($options))->render($s->nisn) . '" alt="' . $s->nisn . '" />', 'nisn' => $s->nisn, 'nama' => $s->nama, 'nomor' => $s->nomor_wali, 'foto' => $s->foto);
        }

        $data['qrcode'] = $qr;

        return view('siswa_qrcode', $data);
    }

    public function siswa_delete_batch()
    {

        $db = db_connect();
        foreach ($this->request->getVar('id') as $id) {
            $db->table('siswa')->where('id', $id)->delete();
        }
        session()->setFlashdata('message', 'Data berhasil dihapus.');
        return redirect()->to(base_url('master/siswa'));
    }

    public function siswa_delete($id)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();
        $del = $db->table('siswa')->where(['id' => $id])->delete();

        session()->setFlashdata('message', 'Data berhasil dihapus.');
        return redirect()->to(base_url('master/siswa'));
    }

    public function finger()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Setting Mesin Fingerprint',
            'subtitle' => 'Setting IP dan Basic mesin finger',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'setting'  => $db->table('setting')->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('finger', $data);
    }

    public function finger_save()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'ip_finger1' => $this->request->getVar('ip_finger1'),
            'ip_finger2' => $this->request->getVar('ip_finger2'),
            'ip_finger3' => $this->request->getVar('ip_finger3'),
            'ip_finger4' => $this->request->getVar('ip_finger4'),
            'ip_finger5' => $this->request->getVar('ip_finger5'),
            'ip_finger6' => $this->request->getVar('ip_finger6'),
            'ip_finger7' => $this->request->getVar('ip_finger7'),
            'ip_finger8' => $this->request->getVar('ip_finger8'),
            'ip_finger9' => $this->request->getVar('ip_finger9'),
            'ip_finger10' => $this->request->getVar('ip_finger10'),
            'jam_masuk'  => $this->request->getVar('jam_masuk'),
            'jam_pulang' => $this->request->getVar('jam_pulang'),
            // 'online_url' => $this->request->getVar('online_url'),
        ];

        $db->table('setting')->where(['id' => 1])->update($data);
        session()->setFlashdata('message', 'Berhasil disimpan');
        return redirect()->to(base_url('master/finger'));
    }

    public function finger_user()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Data User Mesin Fingerprint',
            'subtitle' => 'Data user yang ada di mesin fingerprint',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'setting'  => $db->table('setting')->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('finger_user', $data);
    }

    public function finger_data()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Data Mesin Fingerprint',
            'subtitle' => 'Data absensi kehadiran di mesin fingerprint',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'setting'  => $db->table('setting')->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('finger_data', $data);
    }

    public function finger_import()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Import Data Siswa',
            'subtitle' => 'Imprt data siswa ke dalam mesin fingerprint',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'setting'  => $db->table('setting')->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('finger_import', $data);
    }

    public function finger_import_proses()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $file_excel = $this->request->getFile('file');
        $ext = $file_excel->getClientExtension();
        if ($ext == 'xls') {
            $render = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
        } else {
            $render = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        }
        $spreadsheet = $render->load($file_excel);

        $data = $spreadsheet->getActiveSheet()->toArray();
        foreach ($data as $x => $row) {
            if ($x == 0) {
                continue;
            }

            $IP   = $this->request->getVar('finger');
            $Key  = "0";
            $id   = $row[0];
            $nama = $row[1];

            $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
            if ($Connect) {
                $soap_request = "<SetUserInfo><ArgComKey Xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey><Arg><PIN>" . $id . "</PIN><Name>" . $nama . "</Name></Arg></SetUserInfo>";
                $newLine = "\r\n";
                fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
                fputs($Connect, "Content-Type: text/xml" . $newLine);
                fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
                fputs($Connect, $soap_request . $newLine);
                $buffer = "";
                while ($Response = fgets($Connect, 1024)) {
                    $buffer = $buffer . $Response;
                }
            } else echo "Koneksi Gagal";



            $buffer = Parse_Data($buffer, "<Information>", "</Information>");
            session()->setFlashdata('message', 'Berhasil import excel');
        }

        return redirect()->to('/master/finger_import');
    }

    public function finger_clear()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Clear Data Absensi',
            'subtitle' => 'Bersihkan histori absensi kehadiran',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'setting'  => $db->table('setting')->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('finger_clear', $data);
    }

    public function finger_clear_proses()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $IP = $this->request->getVar('finger');
        $Key = "0";

        $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
        if ($Connect) {
            $soap_request = "<ClearData><ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey><Arg><Value xsi:type=\"xsd:integer\">3</Value></Arg></ClearData>";
            $newLine = "\r\n";
            fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
            fputs($Connect, "Content-Type: text/xml" . $newLine);
            fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
            fputs($Connect, $soap_request . $newLine);
            $buffer = "";
            while ($Response = fgets($Connect, 1024)) {
                $buffer = $buffer . $Response;
            }
        } else echo "Koneksi Gagal";

        $buffer = Parse_Data($buffer, "<Information>", "</Information>");

        session()->setFlashdata('message', $buffer);

        return redirect()->to('/master/finger_clear');
    }

    public function wa()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Setting Whatsapp API',
            'subtitle' => 'Setting pesan untuk whatsapp API',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'setting'  => $db->table('setting')->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('wa', $data);
    }

    public function wa_save()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'whatsapp_api_url'  => $this->request->getVar('whatsapp_api_url'),
            'whatsapp_api_key'  => $this->request->getVar('whatsapp_api_key'),
            'tujuan'            => $this->request->getVar('tujuan'),
            'whatsapp_api_text' => $this->request->getVar('whatsapp_api_text'),
        ];

        $db->table('setting')->where(['id' => 1])->update($data);
        session()->setFlashdata('message', 'Berhasil disimpan');
        return redirect()->to(base_url('master/wa'));
    }


    public function wa_tes()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Tes Kirim Whatsapp API',
            'subtitle' => 'Tes koneksi WA API dengan mengirimkan pesan.',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'setting'  => $db->table('setting')->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('wa_tes', $data);
    }

    public function wa_tes_send()
    {
        $db       = db_connect();
        $set      = $db->table('setting')->where(['id' => 1])->get()->getRow();

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL            => $set->whatsapp_api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => '{
                "recipient_type": "individual",
                "to": "' . $this->request->getVar('phone') . '",
                "type": "text",
                "text": {
                    "body": ' . json_encode($set->whatsapp_api_text) . '
                }
            }',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $set->whatsapp_api_key
            ),
        ));

        $response = json_decode(curl_exec($curl));

        curl_close($curl);
        if ($response->code == 200) {
            session()->setFlashdata('message', 'Pesan berhasil dikirim');
            return redirect()->to(base_url('master/wa_tes'));
        } else {
            session()->setFlashdata('message', 'GAGAL');
            return redirect()->to(base_url('master/wa_tes'));
        }
    }

    public function wa_masal()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Kirim Whatsapp Masal',
            'subtitle' => 'Kirim pesan masal ke nomor wali murid.',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'setting'  => $db->table('setting')->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'kelas'    => $db->table('siswa')->select('kelas')->groupBy('kelas')->orderBy('kelas', 'asc')->get()->getResult(),
        ];
        return view('wa_masal', $data);
    }

    public function wa_masal_send()
    {
        $db    = db_connect();
        $set   = $db->table('setting')->where(['id' => 1])->get()->getRow();
        $siswa = $db->table('siswa')->where('kelas', $this->request->getVar('kelas'))->get()->getResult();

        $hasil = array();
        foreach ($siswa as $s) {
            $receiver = $s->nomor_wali;

            $message  = $this->request->getVar('pesan');
            $searchVal  = array("[NISN]", "[SISWA]", "[KELAS]", "[WALI]");
            $replaceVal = array($s->nisn, $s->nama, $s->kelas, $s->nama_wali);
            $message    = str_replace($searchVal, $replaceVal, $message);

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL            => $set->whatsapp_api_url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING       => '',
                CURLOPT_MAXREDIRS      => 10,
                CURLOPT_TIMEOUT        => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_CUSTOMREQUEST  => 'POST',
                CURLOPT_POSTFIELDS     => '{
                    "recipient_type": "individual",
                    "to": "' . $receiver . '",
                    "type": "text",
                    "text": {
                        "body": ' . json_encode($message) . '
                    }
                }',
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer ' . $set->whatsapp_api_key
                ),
            ));

            $response = json_decode(curl_exec($curl));

            curl_close($curl);

            if ($response->code == 200) {
                $status = 'terkirim';
            } else {
                $status = $response->message;
            }

            $hasil[] = array('nomor' => $receiver, 'terkirim' => $status);
        }
        session()->setFlashdata('message', $hasil);
        return redirect()->to(base_url('master/wa_masal'));
    }

    //WALI KELAS
    public function walikelas()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'     => 'Master Data Wali Kelas',
            'subtitle'  => 'Kelola Wali Kelas',
            'session'   => $this->session->get(),
            'segment'   => $this->request->uri->getSegments(),
            'admin'     => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'walikelas' => $db->table('admin')->where('level', '3')->get()->getResult(),
        ];

        return view('walikelas', $data);
    }

    public function walikelas_data()
    {
        $db = db_connect();
        $data = $db->table('admin')->select('id, email, password, nama, hp, level')->where('level', '3');

        return DataTable::of($data)
            ->add('aksi', function ($row) {
                return '
                <a href="' . base_url('master/walikelas_reset/' . $row->id) . '" class="badge bg-warning text-white"  onclick="return confirm(\'Password di Reset menjadi: 12345\')">Reset Pwd.</a>
                <a href="' . base_url('master/walikelas_delete/' . $row->id) . '" class="badge bg-danger text-white" onclick="return confirm(\'Yakin?\')">Delete</a>
                ';
            })
            ->addNumbering('no')->toJson(true);
    }

    public function walikelas_save($id = null)
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $rules = [
            'email' => [
                'rules' => 'is_unique[admin.email]',
                'errors' => [
                    'is_unique' => 'Email sudah terdaftar.',
                ]
            ],
            'hp' => [
                'rules' => 'is_unique[admin.hp]',
                'errors' => [
                    'is_unique' => 'Nomor Whatsapp sudah terdaftar.',
                ]
            ],
        ];

        if ($this->validate($rules)) {
            $data = [
                'email'    => $this->request->getVar('email'),
                'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT),
                'nama'     => $this->request->getVar('nama'),
                'hp'       => $this->request->getVar('whatsapp'),
                'level'    => 3,
            ];
            $db = db_connect();
            $db->table('admin')->insert($data);
            session()->setFlashdata('message', 'Data berhasil di simpan.');
            return redirect()->to(base_url('master/walikelas'));
        } else {
            session()->setFlashdata('message', 'Gagal.');
            return redirect()->to(base_url('master/walikelas'));
        }
    }

    public function walikelas_reset($id)
    {
        $data = [
            'password' => password_hash('12345', PASSWORD_BCRYPT),
        ];
        $db = db_connect();
        $db->table('admin')->where(['id' => $id])->update($data);
        session()->setFlashdata('message2', 'Password berhasil di Reset.');
        return redirect()->to(base_url('master/walikelas'));
    }

    public function walikelas_delete($id)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();
        $del = $db->table('admin')->where(['id' => $id])->delete();

        session()->setFlashdata('message2', 'Data berhasil dihapus.');
        return redirect()->to(base_url('master/walikelas'));
    }

    //KELAS
    public function kelas()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'     => 'Master Data Kelas',
            'subtitle'  => 'Kelola Kelas',
            'session'   => $this->session->get(),
            'segment'   => $this->request->uri->getSegments(),
            'admin'     => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'kelas'     => $db->table('kelas')->get()->getResult(),
            'walikelas' => $db->table('admin')->where('level', '3')->get()->getResult(),
        ];

        return view('kelas', $data);
    }

    public function kelas_data()
    {
        $db = db_connect();
        $data = $db->table('kelas')->select('kelas.id, kelas.kelas, kelas.id_group, admin.nama as walikelas')
            ->join('admin', 'admin.id=kelas.walikelas');

        return DataTable::of($data)
            ->add('aksi', function ($row) {
                return '<a href="' . base_url('master/kelas_delete/' . $row->id) . '" class="badge bg-danger text-white" onclick="return confirm(\'Yakin?\')">Delete</a>';
            })
            ->addNumbering('no')->toJson(true);
    }

    public function kelas_save($id = null)
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $rules = [
            'kelas' => [
                'rules' => 'is_unique[kelas.kelas]',
                'errors' => [
                    'is_unique' => 'Nama Kelas sudah terdaftar.',
                ]
            ],
        ];

        if ($this->validate($rules)) {
            $data = [
                'kelas'     => $this->request->getVar('kelas'),
                'walikelas' => $this->request->getVar('walikelas'),
                'id_group'  => $this->request->getVar('id_group'),
            ];
            $db = db_connect();
            $db->table('kelas')->insert($data);
            session()->setFlashdata('message', 'Data berhasil di simpan.');
            return redirect()->to(base_url('master/kelas'));
        } else {
            session()->setFlashdata('message', 'Gagal.');
            return redirect()->to(base_url('master/kelas'));
        }
    }

    public function kelas_delete($id)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();
        $del = $db->table('kelas')->where(['id' => $id])->delete();

        session()->setFlashdata('message2', 'Data berhasil dihapus.');
        return redirect()->to(base_url('master/kelas'));
    }
}
