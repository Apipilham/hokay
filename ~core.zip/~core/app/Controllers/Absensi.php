<?php

namespace App\Controllers;

use \Hermawan\DataTables\DataTable;
use \PhpOffice\PhpSpreadsheet\Spreadsheet;
use \PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Absensi extends BaseController
{
    public function riwayat()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Absensi',
            'subtitle' => 'Data absensi yang sudah terekam di batabase lokal',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('absensi', $data);
    }

    public function data()
    {
        $db = db_connect();
        if ($this->session->get()['level'] == 'level_walikelas') {
            $kls = $db->table('kelas')->where('walikelas', $this->session->get()['id'])->get()->getRow();
            $data = $db->table('absensi')->select('absensi.id, absensi.tanggal, absensi.jam, absensi.nisn, absensi.status, absensi.notif_sukses, siswa.nama, siswa.kelas')
                ->join('siswa', 'siswa.nisn=absensi.nisn')
                ->join('kelas', 'kelas.kelas=siswa.kelas')
                ->where('siswa.kelas', $kls->kelas)
                ->orderBy('id', 'DESC');
        } else {
            $data =  $db->table('absensi')->select('absensi.id, absensi.tanggal, absensi.jam, absensi.nisn, absensi.status, absensi.notif_sukses, siswa.nama, siswa.kelas')
                ->join('siswa', 'siswa.nisn=absensi.nisn')
                ->orderBy('id', 'DESC');
        }

        return DataTable::of($data)
            ->add('aksi', function ($row) {
                return '<a href="" class="badge bg-success text-white">Data</a> <a href="" class="badge bg-primary text-white">Edit</a> <a href="" class="badge bg-danger text-white">Delete</a>';
            })
            ->addNumbering('no')->toJson(true);
    }

    public function cek()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();
        $tgl = date("Y-m-d");

        if ($this->session->get()['level'] == 'level_walikelas') {
            $kls = $db->table('kelas')->where('walikelas', $this->session->get()['id'])->get()->getRow();
            $kelas = $kls->kelas;
            $cek = $db->query("SELECT id, nisn, nama, kelas FROM siswa WHERE NOT EXISTS (SELECT * FROM absensi WHERE siswa.nisn=absensi.nisn AND absensi.tanggal='$tgl') AND kelas='$kelas'")->getResult();
        } else {
            $cek = $db->query("SELECT id, nisn, nama, kelas FROM siswa WHERE NOT EXISTS (SELECT * FROM absensi WHERE siswa.nisn=absensi.nisn AND absensi.tanggal='$tgl')")->getResult();
        }

        $data = [
            'title'    => 'Cek Absensi',
            'subtitle' => 'Cek Siswa yang belum absensi',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'cek'      => $cek,
        ];

        return view('absensi_cek', $data);
    }

    public function izin()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();
        $tgl = date("Y-m-d");

        $set = $db->table('setting')->where(['id' => 1])->get()->getRow();

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $set->online_url . "/api/get_izin",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        $response = json_decode($response, true);

        $data = [
            'title'    => 'Izin Absensi',
            'subtitle' => 'Data siswa izin, di ambil dari absensi online',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'izin'     => $response,
            'setting'  => $db->table('setting')->where(['id' => 1])->get()->getRow(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];

        return view('absensi_izin', $data);
    }

    public function manual()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Absensi Manual',
            'subtitle' => 'Absensi manual untuk yang tidak melakukan absensi',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('absensi_manual', $data);
    }

    public function save($id = null)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $cek = $db->table('siswa')->where(['nisn' => $this->request->getVar('nisn')])->get();
        if ($cek->getNumRows() == 0) {
            session()->setFlashdata('message', 'NISN tidak di temukan.');
            return redirect()->to(base_url('absensi/manual'));
        } else {
            $cek = $db->table('absensi')->where(['tanggal' => $this->request->getVar('tanggal'), 'nisn' => $this->request->getVar('nisn'), 'status !=' => 'pulang', 'status !=' => 'diluar'])->get();
            if ($cek->getNumRows() == 0) {
                $data = [
                    'tanggal'      => $this->request->getVar('tanggal'),
                    'jam'          => $this->request->getVar('jam'),
                    'nisn'         => $this->request->getVar('nisn'),
                    'status'       => $this->request->getVar('status'),
                    'notif_sukses' => 0,
                ];

                $db->table('absensi')->insert($data);
                session()->setFlashdata('message', 'Data berhasil disimpan.');
                return redirect()->to(base_url('absensi/manual'));
            } else {
                session()->setFlashdata('message', 'GAGAL, sudah ada data yang sama.');
                return redirect()->to(base_url('absensi/manual'));
            }
        }
    }

    public function laporan()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        if ($this->session->get()['level'] == 'level_walikelas') {
            $kelas = $db->table('kelas')->select('kelas')->where('walikelas', $this->session->get()['id'])->get()->getResult();
        } else {
            $kelas = $db->table('kelas')->select('kelas')->get()->getResult();
        }

        $data = [
            'title'    => 'Laporan',
            'subtitle' => 'Laporan absensi',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'kelas'    => $kelas,
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'db'       => $db,
        ];

        if (isset($_GET['start'])) {
            $s = $_GET['start'];
            $e = $_GET['end'];
            // $t = $_GET['status'];
            $now = strtotime($e); // or your date as well
            $your_date = strtotime($s);
            $datediff = $now - $your_date;

            $count = round($datediff / (60 * 60 * 24)) + 1;

            if ($e < $s) {
                session()->setFlashdata('message', 'Pilih tanggal yang baik dan benar.');
                return redirect()->to(base_url('absensi/laporan'));
            }

            $m = date('m', strtotime($s));
            $nm = date('m', strtotime($e));

            if ($m != $nm) {
                session()->setFlashdata('message', 'Maksimal rentang Tanggal adalah 1 Bulan. Atau hanya bisa dalam 1 bulan');
                return redirect()->to(base_url('absensi/laporan'));
            }

            if ($_GET['kelas'] == 'all') {
                $siswa = $db->table('siswa')->get()->getResult();
            } else {
                $siswa = $db->table('siswa')->where('kelas', $_GET['kelas'])->get()->getResult();
            }
            $data['out'] = '<tbody>';
            $no = 1;
            $s = $_GET['start'];
            $e = $_GET['end'];
            $awal = date('d', strtotime($s));
            $akhir = date('d', strtotime($e));

            $now = strtotime($e); // or your date as well
            $your_date = strtotime($s);
            $datediff = $now - $your_date;

            foreach ($siswa as $row) {
                $data['out'] .= '<tr>';
                $data['out'] .= '<td>' . $no++ . '</td>';
                $data['out'] .= '<td>' . $row->nisn . '</td>';
                $data['out'] .= '<td>' . $row->nama . '</td>';
                $data['out'] .= '<td>' . $row->kelas . '</td>';



                for ($i = $awal; $i <= $akhir; $i++) {
                    $s = date('Y-m-' . $i, strtotime($s));
                    // echo  $s . '<br>';
                    $h = $db->table('absensi')->where(['tanggal' => $s, 'nisn' => $row->nisn, 'status !=' => 'pulang', 'status !=' => 'pulang'])->get()->getRow();
                    if ($h == null) {
                        $data['out'] .= '<td>-</td>';
                    } else {
                        if ($h->status == 'masuk') {
                            $status = '<span class="badge bg-success">H</span>';
                        }
                        if ($h->status == 'terlambat') {
                            $status = '<span class="badge bg-info">T</span>';
                        }
                        if ($h->status == 'sakit') {
                            $status = '<span class="badge bg-purple">S</span>';
                        }
                        if ($h->status == 'izin') {
                            $status = '<span class="badge bg-warning">I</span>';
                        }
                        if ($h->status == 'alpha') {
                            $status = '<span class="badge bg-danger">A</span>';
                        }
                        $data['out'] .= '<td align="center">' . $status . '</td>';
                    }
                }

                $data['out'] .= '</tr>';
            }
            $data['out'] .= '</tbody>';



            $data['filter'] = $db->table('absensi')->where('tanggal >= ', $s)->where('tanggal <= ', $e)->join('siswa', 'siswa.nisn=absensi.nisn')->groupBy('absensi.nisn')->get()->getResult();

            // if ($t == 'masuk') {
            //     $where = "tanggal >= '" . $s . "' AND tanggal <= '" . $e . "' AND (status='masuk' OR status='terlambat')";
            //     $data['filter'] = $db->table('absensi')->where($where)->join('siswa', 'siswa.nisn=absensi.nisn')->get()->getResult();
            // } else {
            //     $data['filter'] = $db->table('absensi')->where('tanggal >= ', $s)->where('tanggal <= ', $e)->where('status', $t)->join('siswa', 'siswa.nisn=absensi.nisn')->get()->getResult();
            // }
        }

        return view('absensi_laporan', $data);
    }

    public function laporan_cetak($s, $e, $t)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        if ($e < $s) {
            session()->setFlashdata('message', 'Pilih tanggal yang baik dan benar.');
            return redirect()->to(base_url('absensi/laporan'));
        }

        if ($t == 'masuk') {
            $where = "tanggal >= '" . $s . "' AND tanggal <= '" . $e . "' AND (status='masuk' OR status='terlambat')";
            $data['filter'] = $db->table('absensi')->where($where)->join('siswa', 'siswa.nisn=absensi.nisn')->get()->getResult();
        } else {
            $data['filter'] = $db->table('absensi')->where('tanggal >= ', $s)->where('tanggal <= ', $e)->where('status', $t)->join('siswa', 'siswa.nisn=absensi.nisn')->get()->getResult();
        }

        $data['segment'] = $this->request->uri->getSegments();


        return view('absensi_cetak', $data);
    }
}
