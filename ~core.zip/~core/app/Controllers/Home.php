<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		if ($this->session->get('logged_in') != null) {
			return redirect()->to('/dashboard');
		}

		$data = [
			'title' => 'Login',
			'session' => $this->session->get(),
			'segment' => $this->request->uri->getSegments(),
		];

		return view('login', $data);
	}

	public function login()
	{
		$db = db_connect();

		$e = $this->request->getVar('email');
		$p = $this->request->getVar('password');
		$cek = $db->table('admin')->where(['email' => $e])->get();

		if ($cek->getNumRows() > 0) {
			$row = $cek->getRow();
			if (password_verify($p, $row->password)) {
				if ($row->level == 1) {
					$sesi = [
						'id'        => $row->id,
						'nama'      => $row->nama,
						'email'     => $row->email,
						'hp'        => $row->hp,
						'level'     => 'level_admin',
						'logged_in' => true,
					];
				} else if ($row->level == 2) {
					$sesi = [
						'id'        => $row->id,
						'nama'      => $row->nama,
						'email'     => $row->email,
						'hp'        => $row->hp,
						'level'     => 'level_operator',
						'logged_in' => true,
					];
				} else if ($row->level == 3) {
					$sesi = [
						'id'        => $row->id,
						'nama'      => $row->nama,
						'email'     => $row->email,
						'hp'        => $row->hp,
						'level'     => 'level_walikelas',
						'logged_in' => true,
					];
				}

				$this->session->set($sesi);
				return redirect()->to(base_url('/admin/dashboard'));
			} else {
				session()->setFlashdata('message', 'Login Gagal, Password tidak cocok.');
				return redirect()->to(base_url('/login'));
			}
		} else {
			session()->setFlashdata('message', 'Login Gagal, User tidak ditemukan.');
			return redirect()->to(base_url('/login'));
		}
	}

	public function logout()
	{
		unset(
			$_SESSION['id'],
			$_SESSION['nama'],
			$_SESSION['email'],
			$_SESSION['hp'],
			$_SESSION['level'],
			$_SESSION['logged_in'],
		);
		return redirect()->to(base_url('/'));
	}
}
