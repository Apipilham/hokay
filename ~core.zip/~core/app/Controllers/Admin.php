<?php

namespace App\Controllers;

class Admin extends BaseController
{
    public function dashboard()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $hari_ini = date("Y-m-d");

        $data = [
            'title'                   => 'Dashboard',
            'subtitle'                => 'Dasboard Statistik',
            'session'                 => $this->session->get(),
            'segment'                 => $this->request->uri->getSegments(),
            'admin'                   => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'total_admin'             => $db->table('admin')->get()->getNumRows(),
            'total_walikelas'         => $db->table('admin')->where('level', '3')->get()->getNumRows(),
            'total_siswa'             => $db->table('siswa')->get()->getNumRows(),
            'total_siswa_hadir'       => $db->table('absensi')->where(['tanggal' => $hari_ini, 'status' => 'masuk'])->get()->getNumRows(),
            'total_siswa_terlambat'   => $db->table('absensi')->where(['tanggal' => $hari_ini, 'status' => 'terlambat'])->get()->getNumRows(),
            'total_siswa_belum_absen' => $db->query("SELECT count(*) as total FROM siswa WHERE NOT EXISTS (SELECT * FROM absensi WHERE siswa.nisn=absensi.nisn AND absensi.tanggal='$hari_ini')")->getResult(),
        ];

        return view('admin_dashboard', $data);
    }

    public function index()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Administrator',
            'subtitle' => 'Update data administrator',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('admin', $data);
    }

    public function save()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'nama'  => $this->request->getVar('nama'),
            'email' => $this->request->getVar('email'),
            'hp'    => $this->request->getVar('hp'),
        ];

        $db->table('admin')->where(['id' => 1])->update($data);
        session()->setFlashdata('message', 'Berhasil disimpan');
        return redirect()->to(base_url('admin'));
    }

    public function password()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Ubah Password',
            'subtitle' => 'Ubah Password administrator',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
        ];
        return view('password', $data);
    }

    public function reset()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'password'  => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
        ];

        $db->table('admin')->where(['id' => 1])->update($data);
        session()->setFlashdata('message', 'Berhasil disimpan');
        return redirect()->to(base_url('admin/password'));
    }
}
