<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {

        $data = [
            'title'   => 'Dashboard Absensi',
            'session' => $this->session->get(),
            'segment' => $this->request->uri->getSegments(),
        ];
        return view('dashboard', $data);
    }

    public function qrcode()
    {
        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/login');
        }

        $data = [
            'title'   => 'Dashboard Absensi',
            'session' => $this->session->get(),
            'segment' => $this->request->uri->getSegments(),
        ];
        return view('qrcode', $data);
    }

    public function qr_save()
    {
        $db = db_connect();

        $set = $db->table('setting')->get()->getRow();
        $jam_masuk = explode('-', $set->jam_masuk);
        $jam_pulang = explode('-', $set->jam_pulang);

        $nisn = $this->request->getVar('qrcode');
        $jam = date("H:i:s");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $db->table('siswa')->where('nisn', $nisn)->get()->getNumRows();
        if ($cek != 0) {
            $cek_absensi = $db->table('absensi')->where(['nisn' => $nisn, 'tanggal' => date("Y-m-d"), 'status' => $status])->get()->getNumRows();
            if ($cek_absensi == 0) {
                $data = [
                    'nisn' => $nisn,
                    'tanggal' => date("Y-m-d"),
                    'jam' => $jam,
                    'status' => $status,
                    'notif_sukses' => $notif
                ];
                $db->table('absensi')->insert($data);
                return redirect()->to(base_url('dashboard/qrcode'));
            } else {
                return redirect()->to(base_url('dashboard/qrcode'));
            }
        } else {
            session()->setFlashdata('message', 'Data tidak ditemukan');
            return redirect()->to(base_url('dashboard/qrcode'));
        }
    }
}
