<?php

namespace App\Controllers;

use \Hermawan\DataTables\DataTable;

class User extends BaseController
{
    public function index()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Daftar User',
            'subtitle' => 'Daftar User Login',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'user'     => $db->table('admin')->get()->getResult()
        ];
        return view('user', $data);
    }

    public function user_data()
    {
        $db = db_connect();
        $data = $db->table('admin')->select('id, nama, email, password, hp, level');

        return DataTable::of($data)
            ->add('level', function ($row) {
                if ($row->level == 1) {
                    return '<span class="badge bg-primary">Administrator</span>';
                } else {
                    return '<span class="badge bg-warning">Operator</span>';
                }
            })
            ->add('aksi', function ($row) {
                if ($row->id == 1) {
                    return '
                    <a href="' . base_url('user/edit/' . $row->id) . '" class="badge bg-info text-white">Edit</a> 
                    <a href="' . base_url('user/reset/' . $row->id) . '" class="badge bg-success text-white" onclick="return confirm(\'Password default: 12345\')">Reset Pwd.</a> ';
                } else {
                    return '
                    <a href="' . base_url('user/edit/' . $row->id) . '" class="badge bg-info text-white">Edit</a> 
                    <a href="' . base_url('user/reset/' . $row->id) . '" class="badge bg-success text-white" onclick="return confirm(\'Password default: 12345\')">Reset Pwd.</a> 
                    <a href="' . base_url('user/delete/' . $row->id) . '" class="badge bg-danger text-white" onclick="return confirm(\'Yakin?\')">Delete</a>';
                }
            })
            ->addNumbering('no')->toJson(true);
    }

    public function add()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Tambah User',
            'subtitle' => 'Form tambah user baru',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'user'     => $db->table('admin')->get()->getResult()
        ];
        return view('user_add', $data);
    }

    public function edit($id)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'title'    => 'Edit User',
            'subtitle' => 'Form edit user',
            'session'  => $this->session->get(),
            'segment'  => $this->request->uri->getSegments(),
            'admin'    => $db->table('admin')->where(['id' => $this->session->get()['id']])->get()->getRow(),
            'user'     => $db->table('admin')->where(['id' => $id])->get()->getRow()
        ];
        return view('user_edit', $data);
    }

    public function save()
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $rules = [
            'email' => [
                'rules' => 'is_unique[admin.email,id,{id}]',
                'errors' => [
                    'is_unique' => 'Email sudah terdaftar.',
                ]
            ],
            'hp' => [
                'rules' => 'is_unique[admin.hp,id,{id}]',
                'errors' => [
                    'is_unique' => 'Nomor Whatsapp sudah terdaftar.',
                ]
            ],
        ];

        $data = [
            'nama'     => $this->request->getVar('nama'),
            'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT),
            'email'    => $this->request->getVar('email'),
            'hp'       => $this->request->getVar('hp'),
            'level'    => $this->request->getVar('level'),
        ];

        if (empty($this->request->getVar('id'))) {
            if ($this->validate($rules)) {
                $db->table('admin')->insert($data);
                session()->setFlashdata('message', 'Berhasil disimpan');
                return redirect()->to(base_url('user/add'));
            } else {
                session()->setFlashdata('message', 'Gagal. Email atau Nomor WA sudah terdaftar.');
                return redirect()->to(base_url('user/add'));
            }
        } else {
            if ($this->validate($rules)) {
                $db->table('admin')->where(['id' => $this->request->getVar('id')])->update($data);
                session()->setFlashdata('message', 'Data berhasil di simpan.');
                return redirect()->to(base_url('user/edit/' . $this->request->getVar('id')));
            } else {
                session()->setFlashdata('message', 'Gagal. Email atau Nomor WA sudah terdaftar.');
                return redirect()->to(base_url('user/edit/' . $this->request->getVar('id')));
            }
        }
    }

    public function reset($id)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();

        $data = [
            'password'  => password_hash(12345, PASSWORD_DEFAULT),
        ];

        $db->table('admin')->where(['id' => $id])->update($data);
        session()->setFlashdata('message', 'Berhasil disimpan');
        return redirect()->to(base_url('user'));
    }

    public function delete($id)
    {

        if ($this->session->get('logged_in') == null) {
            return redirect()->to('/');
        }

        $db = db_connect();
        $del = $db->table('admin')->where(['id' => $id])->delete();

        session()->setFlashdata('message', 'Data berhasil dihapus.');
        return redirect()->to(base_url('user'));
    }
}
