<?php
error_reporting(0);
include('conn.php');

$con->query("OPTIMIZE TABLE `absensi`");

$cek = $con->prepare("SELECT * FROM setting WHERE id=1");
$cek->execute();
$set = $cek->fetch(PDO::FETCH_OBJ);
$jam_masuk = explode('-', $set->jam_masuk);
$jam_pulang = explode('-', $set->jam_pulang);

if ($set->ip_finger1 != '') {
    $IP = $set->ip_finger1;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger2 != '') {
    $IP = $set->ip_finger2;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger3 != '') {
    $IP = $set->ip_finger3;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger4 != '') {
    $IP = $set->ip_finger4;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger5 != '') {
    $IP = $set->ip_finger5;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger6 != '') {
    $IP = $set->ip_finger6;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger7 != '') {
    $IP = $set->ip_finger7;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger8 != '') {
    $IP = $set->ip_finger8;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger9 != '') {
    $IP = $set->ip_finger9;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

if ($set->ip_finger10 != '') {
    $IP = $set->ip_finger10;
    $Key = "0";

    $Connect = fsockopen($IP, "80", $errno, $errstr, 1);
    if ($Connect) {
        $soap_request = "<GetAttLog>
                            <ArgComKey xsi:type=\"xsd:integer\">" . $Key . "</ArgComKey>
                            <Arg>
                                <PIN xsi:type=\"xsd:integer\">All</PIN>
                            </Arg>
                        </GetAttLog>";

        $newLine = "\r\n";
        fputs($Connect, "POST /iWsService HTTP/1.0" . $newLine);
        fputs($Connect, "Content-Type: text/xml" . $newLine);

        fputs($Connect, "Content-Length: " . strlen($soap_request) . $newLine . $newLine);
        fputs($Connect, $soap_request . $newLine);
        $buffer = "";
        while ($Response = fgets($Connect, 1024)) {
            $buffer = $buffer . $Response;
        }
    } else echo "<div class='alert alert-danger'>Koneksi ke Mesin dengan IP: " . $IP . " Gagal</div>";

    $buffer = Parse_Data($buffer, "<GetAttLogResponse>", "</GetAttLogResponse>");
    $buffer = explode("\r\n", $buffer);
    $hari_ini = date("Y-m-d");

    for ($a = 1; $a < count($buffer) - 1; $a++) {
        $data = Parse_Data($buffer[$a], "<Row>", "</Row>");
        $pin = Parse_Data($data, "<PIN>", "</PIN>");
        $tgl = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 0, 10);
        $jam = substr(Parse_Data($data, "<DateTime>", "</DateTime>"), 11, 8);
        $status = Parse_Data($data, "<Status>", "</Status>");

        if ($jam > $jam_masuk[0] and $jam < $jam_masuk[1]) {
            $status = 'masuk';
            $notif = 0;
        } else if ($jam > $jam_masuk[1] and $jam < $jam_pulang[0]) {
            $status = 'terlambat';
            $notif = 0;
        } else if ($jam > $jam_pulang[0] and $jam < $jam_pulang[1]) {
            $status = 'pulang';
            $notif = 0;
        } else {
            $status = 'diluar';
            $notif = 3;
        }

        $cek = $con->prepare("SELECT nisn FROM absensi WHERE nisn=? AND tanggal=? AND status=?");
        $cek->execute([$pin, $tgl, $status]);
        if ($cek->rowCount() == 0) {
            // $rand = rand(0, 1);
            $in = $con->prepare("INSERT INTO absensi(tanggal, jam, nisn, status, notif_sukses) VALUES(?,?,?,?,?)");
            $in->execute([$tgl, $jam, $pin, $status, $notif]);
        }
    }
}

function Parse_Data($data, $p1, $p2)
{
    $data = " " . $data;
    $hasil = "";
    $awal = strpos($data, $p1);
    if ($awal != "") {
        $akhir = strpos(strstr($data, $p1), $p2);
        if ($akhir != "") {
            $hasil = substr($data, $awal + strlen($p1), $akhir - strlen($p1));
        }
    }
    return $hasil;
}
?>

<h4>Hari ini: <?= date("Y-m-d H:i"); ?></h4>

Riwayat 20 absensi terakhir:

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>TANGGAL</th>
            <th>NIS</th>
            <th>NAMA</th>
            <th>STATUS</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = $con->prepare("SELECT * FROM absensi JOIN siswa ON siswa.nisn=absensi.nisn WHERE absensi.tanggal=? ORDER by absensi.id DESC LIMIT 20");
        $sql->execute([date("Y-m-d")]);
        if ($sql->rowCount() == 0) {
            echo '<tr><td colspan="5">data kosong</td></tr>';
        } else {
            $r = $sql->fetchAll(PDO::FETCH_OBJ);
            foreach ($r as $row) {

                if ($row->notif_sukses == 0) {
                    $notif = 'Gagal <a href="">Kirim Manual</a>';
                } else if ($row->notif_sukses == 1) {
                    $notif = 'Sukses';
                }
                echo '
            <tr>
                <td>' . $row->tanggal . ' ' . $row->jam . '</td>
                <td>' . $row->nisn . '</td>
                <td>' . $row->nama . '</td>
                <td>' . $row->status . '</td>
            </tr>
            ';
            }
        }
        ?>
    </tbody>
</table>