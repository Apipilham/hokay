<h2>Sending service Whatsapp</h2>
<div id="data2"></div>

<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>

<script>
    var autoload2 = setInterval(
        function() {
            $('#data2').load('send.php').fadeIn('slow');
        }, 10000
    );
</script>