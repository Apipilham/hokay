<?php
include('conn.php');

$sisa = $con->prepare("SELECT * FROM absensi JOIN siswa ON siswa.nisn=absensi.nisn WHERE tanggal=? AND notif_sukses=?");
$sisa->execute([date("Y-m-d"), 0]);

$sudah = $con->prepare("SELECT * FROM absensi JOIN siswa ON siswa.nisn=absensi.nisn WHERE tanggal=? AND notif_sukses=?");
$sudah->execute([date("Y-m-d"), 1]);

$tidak_terdaftar = $con->prepare("SELECT * FROM absensi JOIN siswa ON siswa.nisn=absensi.nisn WHERE tanggal=? AND notif_sukses=?");
$tidak_terdaftar->execute([date("Y-m-d"), 2]);

$total = $con->prepare("SELECT * FROM absensi JOIN siswa ON siswa.nisn=absensi.nisn WHERE tanggal=?");
$total->execute([date("Y-m-d")]);

echo '<hr>';
echo '<b>Statistik hari ini:</b><br>';
echo 'kode acak: ' . rand(12, 21) . '<br>';
echo 'total: ' . $total->rowCount() . '<br>';
echo 'selesai: ' . $sudah->rowCount() . '<br>';
echo 'sisa antrian: ' . $sisa->rowCount() . '<br>';
echo 'Nomor tidak terdaftar: ' . $tidak_terdaftar->rowCount() . '<br>';

$s = $con->prepare("SELECT * FROM setting WHERE id=1");
$s->execute();
$set = $s->fetch(PDO::FETCH_OBJ);

if ($set->tujuan == 1) {
    $tujuan = 'individual';
} else if ($set->tujuan == 2) {
    $tujuan = 'group';
}


$cek = $con->prepare("SELECT * FROM absensi JOIN siswa ON siswa.nisn=absensi.nisn WHERE tanggal=? AND notif_sukses=? ORDER BY absensi.id ASC LIMIT 10");
$cek->execute([date("Y-m-d"), 0]);

$row = $cek->fetchAll(PDO::FETCH_OBJ);
$output = array();
foreach ($row as $siswa) {
    $receiver   = $siswa->nomor_wali;
    $pesan      = $set->whatsapp_api_text;
    $searchVal  = array("[NISN]", "[SISWA]", "[KELAS]", "[TANGGAL]", "[JAM]", "[STATUS]", "[WALI]");
    $replaceVal = array($siswa->nisn, $siswa->nama, $siswa->kelas, $siswa->tanggal, $siswa->jam, $siswa->status, $siswa->nama_wali);
    $message    = str_replace($searchVal, $replaceVal, $pesan);

    //get group id
    $kls = $con->prepare("SELECT * FROM kelas WHERE kelas=?");
    $kls->execute([$siswa->kelas]);
    $row_kls = $kls->fetch(PDO::FETCH_OBJ);
    $group = $row_kls->id_group;

    if ($set->tujuan == 1) {
        $receiver = $siswa->nomor_wali;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL            => $set->whatsapp_api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => '{
            "recipient_type": "' . $tujuan . '",
            "to": "' . $receiver . '",
            "type": "text",
            "text": {
                "body": ' . json_encode($message) . '
            }
        }',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $set->whatsapp_api_key
            ),
        ));

        $res = json_decode(curl_exec($curl));

        curl_close($curl);
    } else if ($set->tujuan == 2) {
        $receiver = $group;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL            => $set->whatsapp_api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => '{
            "recipient_type": "' . $tujuan . '",
            "to": "' . $receiver . '",
            "type": "text",
            "text": {
                "body": ' . json_encode($message) . '
            }
        }',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $set->whatsapp_api_key
            ),
        ));

        $res = json_decode(curl_exec($curl));

        curl_close($curl);
    } else if ($set->tujuan == 3) {
        $receiver1 = $siswa->nomor_wali;
        $receiver2 = $group;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL            => $set->whatsapp_api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => '{
            "recipient_type": "individual",
            "to": "' . $receiver1 . '",
            "type": "text",
            "text": {
                "body": ' . json_encode($message) . '
            }
        }',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $set->whatsapp_api_key
            ),
        ));

        $res = json_decode(curl_exec($curl));

        curl_close($curl);

        //send group
        $curl2 = curl_init();

        curl_setopt_array($curl2, array(
            CURLOPT_URL            => $set->whatsapp_api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => '{
            "recipient_type": "group",
            "to": "' . $receiver2 . '",
            "type": "text",
            "text": {
                "body": ' . json_encode($message) . '
            }
        }',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $set->whatsapp_api_key
            ),
        ));

        $res = json_decode(curl_exec($curl2));

        curl_close($curl2);
    }


    if ($res->code == 200) {
        $tgl = date("Y-m-d");
        $u = $con->prepare("UPDATE absensi SET notif_sukses=1 WHERE nisn='$siswa->nisn'");
        $u->execute();
        $hasil_pesan = 'Notifikasi berhasil terkirim ke nomor tujuan';
        $terkirim = 1;
    } else if ($res->code == 400) {
        $tgl = date("Y-m-d");
        $u = $con->prepare("UPDATE absensi SET notif_sukses=2 WHERE nisn='$siswa->nisn'");
        $u->execute();
        $hasil_pesan = 'Gagal, nomor tujuan tidak terdaftar Whatsapp';
        $terkirim = 0;
    }

    $output[] = array('nama' => $siswa->nama, 'receiver' => $receiver, 'terkirim' => $terkirim);
}

echo '<hr>';
echo '<p>Report:</p>';
?>
<?php foreach ($output as $p) : ?>
    <?php
    if ($p['terkirim'] == 1) {
        $terkirim = '<span style="color: green; font-weight: bold;">Terkirim</span>';
    } else {
        $terkirim = '<span style="color: red; font-weight: bold;">Gagal</span>';
    }
    ?>
    <ul>
        <li><b><?= $p['nama'] ?></b> (<?= $p['receiver'] ?>) &raquo; <?= $terkirim ?></li>
    </ul>
<?php endforeach ?>